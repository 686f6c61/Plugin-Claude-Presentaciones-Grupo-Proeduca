---
name: presentacion-proeduca
description: Crea presentaciones con la plantilla oficial de las instituciones de PROEDUCA, UNIR (La Universidad en Internet) y UNIPRO (Universitat Digital Europea), y las entrega en PowerPoint (.pptx), PDF y HTML, con su logotipo, colores y tipografías, figuras en los colores corporativos y citas y referencias en formato APA. Úsala cuando pidan una presentación, un PowerPoint, un pptx, unas diapositivas, un deck, una defensa de TFG o TFM, una clase o un informe en diapositivas de UNIR, de UNIPRO o de PROEDUCA, o con la plantilla, la marca o el estilo de alguna de ellas.
dependencies: python-pptx>=1.0, resvg-py>=0.3, pymupdf>=1.24
---

# Presentaciones PROEDUCA

Genera un `.pptx` editable sobre la plantilla oficial de una institución de PROEDUCA. No se escribe código de python-pptx: se redacta una especificación JSON y `scripts/generar.py` monta la presentación con los diseños, posiciones y estilos de la plantilla.

Las rutas de este documento son relativas al directorio de esta skill.

## Primero: para qué institución

Hay dos plantillas y no se parecen. Antes de nada hay que saber cuál toca:

| Institución | Clave | Aspecto |
|---|---|---|
| UNIR, La Universidad en Internet | `unir` | Portada con degradado azul, títulos en mayúsculas, todo en Arial |
| UNIPRO, Universitat Digital Europea | `unipro` | Portada azul lisa, título de dos líneas con barra lateral, iconos |

- Si el usuario nombra la institución, o se deduce sin duda del material que aporta (un logotipo, una guía docente, un nombre de asignatura con la universidad), usar esa.
- **Si no la dice, preguntar para qué institución es antes de escribir el guion.** No elegir una por defecto ni generar las dos. Es una sola pregunta con las dos opciones.
- La clave va en el campo `institucion` de la especificación; sin él, el generador no genera.

## Flujo

1. **Entender el encargo.** Institución, tema, público, duración o número aproximado de diapositivas y material de partida. Lo que falte y no se pueda deducir, preguntarlo de una vez.
2. **Escribir el guion y criticarlo** antes de generar nada, siguiendo [references/guion.md](references/guion.md): un título que afirma algo por diapositiva, una idea por diapositiva y el tipo que corresponde a la forma del contenido. Enseñar el guion al usuario cuando la presentación pase de unas seis diapositivas o el encargo sea abierto.
3. **Dibujar las figuras** que el contenido necesite (diagramas, procesos, esquemas) en SVG con la paleta de la institución, según [references/figuras.md](references/figuras.md). Partir de los modelos de `marcas/<institucion>/figuras/`. Comprobar cada una con `uv run scripts/figura.py --institucion <clave> figura.svg figura.png` y mirar el PNG.
4. **Escribir la especificación** en un archivo JSON. El formato de cada tipo, sus límites y las diferencias entre instituciones están en [references/tipos-diapositiva.md](references/tipos-diapositiva.md); leerlo antes de la primera especificación. Hay un ejemplo completo por institución: [references/ejemplo-unir.json](references/ejemplo-unir.json) y [references/ejemplo-unipro.json](references/ejemplo-unipro.json).
5. **Generar**:

   ```bash
   uv run scripts/generar.py especificacion.json salida.pptx
   ```

   Los `[!] Error` impiden generar y hay que corregirlos; los `[*] Aviso` señalan textos que pueden desbordar.
6. **Auditar** el archivo. No necesita LibreOffice:

   ```bash
   uv run scripts/auditar.py salida.pptx
   ```

   Avisa de textos que se salen, invaden el pie o se montan sobre otra forma, de celdas que no caben, de restos de texto de ejemplo, de datos sin fuente y de tipos repetidos. Son estimaciones: corregir lo que señale y, si un aviso parece falso, confirmarlo en la revisión visual.
7. **Revisar visualmente**:

   ```bash
   uv run scripts/revisar.py salida.pptx revision.png
   ```

   Mirar la hoja de contactos en este orden: texto cortado o desbordado; formas que se montan; citas o pies que chocan con el contenido; huecos desiguales y columnas desalineadas; figuras ilegibles. Reunir todos los fallos, corregir la especificación de una vez y regenerar. Si el script sale con código 3 (no hay LibreOffice), entregar con la auditoría hecha y avisar de que falta la revisión visual.
8. **Exportar** a PDF y a HTML, salvo que el usuario solo quiera el PowerPoint:

   ```bash
   uv run scripts/exportar.py salida.pptx
   ```

   Deja `salida.pdf` y `salida.html` junto al `.pptx` (`--pdf` o `--html` para uno solo, `--salida CARPETA` para otro destino). El HTML es un único archivo autocontenido que se abre en cualquier navegador, con navegación por teclado, texto alternativo y notas del orador. Necesita LibreOffice: con código 3, entregar solo el `.pptx` y decir que los otros dos formatos no se han podido generar.
9. **Entregar** los tres archivos y resumir en dos o tres líneas qué contienen. Mencionar siempre los avisos sin resolver. El `.pptx` es el original editable; el PDF y el HTML son copias para ver y compartir y los dibuja LibreOffice, así que en un equipo sin las fuentes de la plantilla pueden diferir un poco de lo que muestre PowerPoint.

Sin `uv`, sustituir `uv run` por `python3`. Si falta un módulo (`pptx`, `resvg_py`), instalarlo con `pip install python-pptx resvg-py pymupdf pillow`. Si no se puede instalar, decírselo al usuario: no hay forma alternativa de generar el archivo.

## Datos, citas y referencias

- **No inventar.** Las cifras, fechas, nombres y citas salen del material del usuario o de fuentes consultadas. Si un dato falta, pedirlo o dejar la diapositiva fuera. Si la fuente no sostiene una afirmación, matizarla u omitirla.
- **Los gráficos se hacen con datos reales.** Los valores de un gráfico salen de los datos del usuario o de un cálculo hecho sobre ellos (si hay un conjunto de datos disponible, calcularlo con código en vez de estimarlo). No se dibujan nubes de puntos, rectas ni barras con valores puestos para ilustrar; un esquema conceptual va como `figura` y su pie dice que es un esquema.
- **Los números se escriben en español**: coma decimal, los mismos decimales en valores comparables, sin notación científica y con signo menos tipográfico. Las reglas están en [references/guion.md](references/guion.md#números-y-fórmulas).
- **Citar siempre que se use una fuente.** Toda diapositiva que tome datos, ideas, figuras o citas textuales de una obra lleva esa obra en su campo `fuentes`. El generador escribe al pie la cita breve en formato APA, «Autor (año)».
- **Datos propios.** Los gráficos, tablas, cifras y figuras elaborados por el usuario llevan `nota_fuente`, por ejemplo «Elaboración propia» o «Elaboración propia a partir de datos del INE (2024)». La auditoría avisa si una diapositiva de datos no lleva fuente.
- **Lista final.** El generador añade al final, antes del cierre, la diapositiva «Referencias» con todas las obras citadas, en formato APA 7, por orden alfabético y con sangría francesa; si no caben, la reparte en varias. No hay que escribirla a mano.
- **Formato de cada obra.** Cada entrada de `referencias` se escribe completa en APA 7; las reglas y ejemplos están en [references/tipos-diapositiva.md](references/tipos-diapositiva.md#referencias-y-citas-apa). No completar con suposiciones los datos bibliográficos que falten: pedirlos.
- **Citas en el texto.** Dentro de un párrafo, la cita va entre paréntesis, «(García y López, 2024)», y la obra se añade igualmente a `fuentes`.

## Elegir el tipo de diapositiva

| Tipo | Para qué sirve | UNIR | UNIPRO |
|---|---|---|---|
| `portada` | Primera diapositiva: título, autor y pie con fecha o proyecto | sí | sí |
| `separador` | Abre una sección, con número grande | azul, blanco o negro | marino o azul |
| `agenda` | Índice numerado de la sesión | sí | no |
| `texto` | Una idea con entradilla y uno o dos párrafos, o una lista de puntos | sí | sí |
| `cita` | Una frase destacada a toda la diapositiva, con su autor | sí | no |
| `columnas` | De 2 a 4 bloques paralelos con rótulo y puntos | numeradas | con iconos |
| `grafico` | Gráfico nativo de columnas, de líneas o de dispersión, con datos reales | sí | sí |
| `cifras` | De 2 a 4 cifras destacadas con su explicación | sobre franja azul | con línea vertical |
| `tabla` | Datos tabulados, con fila de total opcional | sí | sí |
| `cronologia` | De 3 a 6 hitos en orden (agenda, fases, calendario) | cajas numeradas | línea de tiempo |
| `figura` | Diagrama o esquema dibujado en SVG, o una imagen, con pie y puntos opcionales | sí | sí |
| `referencias` | Lista APA final; solo se incluye para cambiar su posición o su título | sí | sí |
| `cierre` | Última diapositiva | «Gracias» | «Muchas gracias» |

La misma especificación sirve para las dos instituciones cambiando `institucion`, salvo los tipos y campos que una de ellas no tiene; el generador lo indica.

## Lo que no se cambia

La plantilla fija el logotipo, los colores, las tipografías, los tamaños y las posiciones; están descritos en [references/marca-unir.md](references/marca-unir.md) y [references/marca-unipro.md](references/marca-unipro.md). No modificar los archivos de `marcas/`, no añadir formas a mano con python-pptx, no sustituir fuentes o colores y no mezclar elementos de una institución en la presentación de la otra. Si el usuario pide algo que la plantilla no contempla (otro tipo de gráfico, más de cuatro columnas, fotografías), decirlo y ofrecer el tipo disponible más cercano; un diagrama que ningún tipo cubre se dibuja como `figura`.

Los datos cuantitativos van en `grafico` o `tabla`, que son nativos y editables, no en una figura.

UNIPRO usa en portada y separadores la fuente corporativa Proeduca Sans Light. Si el equipo donde se abra el archivo no la tiene instalada, PowerPoint la sustituye por otra, y la revisión visual tampoco la reproduce con exactitud: conviene dejar holgura en esos títulos y avisar de ello al entregar. UNIR va entera en Arial y no tiene ese problema.
