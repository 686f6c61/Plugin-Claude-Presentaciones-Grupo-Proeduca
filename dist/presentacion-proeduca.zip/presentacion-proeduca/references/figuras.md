# Figuras en SVG

Cuando una idea se explica mejor con un diagrama (un proceso, una estructura, un ciclo, una relación entre elementos), se dibuja en SVG con la paleta de la institución y `scripts/figura.py` lo convierte en PNG. El generador acepta el `.svg` directamente en el campo `imagen` de una diapositiva `figura` y lo convierte al vuelo.

## Datos reales o esquema, nunca una mezcla

- **Los datos no se dibujan a mano.** Una nube de puntos, una recta ajustada, unas barras o una curva con valores van en `grafico` (columnas, líneas o dispersión) o en `tabla`, que son nativos, editables y salen de los datos.
- **Una figura es un esquema**: muestra una idea, una estructura o un proceso, no valores. Si incluye ejes, puntos o curvas para explicar un concepto (por ejemplo, el efecto de un punto con mucha palanca), son ilustrativos y su pie lo dice: «Figura 2. Esquema del efecto de un punto con palanca alta.» No se rotulan ejes con cifras inventadas ni se colocan puntos que parezcan observaciones.
- **Una figura adaptada de una obra** reproduce la relación que muestra el original, lleva la obra en `fuentes` y su pie dice «Adaptado de…».

Un esquema con pocos puntos regulares y líneas perfectas, presentado como si fueran datos, se nota artificial y resta credibilidad al resto de la presentación.

## Paleta de cada institución

Solo se admiten los colores de la institución, escritos en hexadecimal de seis dígitos. `figura.py` rechaza cualquier otro, también los nombres de color (`red`) y `rgb()`.

| Papel | UNIR | UNIPRO |
|---|---|---|
| Principal: elementos destacados | `#0D61F2` azul | `#0A5CF5` azul |
| Secundario; texto sobre fondos claros | `#052761` azul marino | `#01224E` azul marino |
| Acento: lo que hay que destacar, una sola vez por figura | `#E328CC` magenta | `#FF7475` coral |
| Texto sobre el acento | `#FFFFFF` blanco | `#01224E` azul marino |
| Líneas, flechas y texto secundario | `#535353` gris oscuro | `#44546A` gris azulado |
| Elementos de contexto | `#959CAF` gris azulado | `#A5A5A5` gris medio |
| Fondos de bloques y agrupaciones | `#D3D6DE` gris claro | `#E7E6E6` gris claro |
| Texto sobre azul y azul marino | `#FFFFFF` blanco | `#FFFFFF` blanco |
| Otros admitidos | `#41EBCC` turquesa, `#000000` negro | ninguno |

- El azul domina; el acento se reserva para un único elemento.
- Los matices se consiguen con `fill-opacity` u `opacity` sobre un color de la paleta, nunca con otro hexadecimal.
- No poner texto gris sobre fondo claro ni texto azul marino sobre el magenta de UNIR.
- El fondo de la figura queda transparente: la diapositiva es blanca.
- Los colores de una institución no se usan en las figuras de la otra, aunque se parezcan.

## Lienzo y texto

- `viewBox` obligatorio, sin `width` ni `height`. Usar `viewBox="0 0 1200 500"` para una figura a todo el ancho y `viewBox="0 0 800 560"` cuando la diapositiva lleva `puntos` a la izquierda.
- `font-family="Arial, Helvetica, sans-serif"` en el elemento `<svg>`.
- Tamaños de letra para un `viewBox` de 1200 de ancho: rótulos principales de 30 a 36, texto secundario de 20 a 24, y nunca por debajo de 15. Con otro ancho, escalar en proporción. `figura.py` avisa si el texto queda demasiado pequeño.
- El texto no se ajusta solo: partir a mano las líneas largas con varios `<text>` o `<tspan>`. Como referencia, a tamaño 22 caben unos 28 caracteres en una caja de 320 de ancho.
- Margen de 30 unidades como mínimo entre el contenido y el borde del `viewBox`, y no dejar grandes zonas vacías: el generador escala la figura entera, y el espacio vacío encoge el dibujo y su texto.
- Con `puntos` a la izquierda, la figura se muestra a poco más de la mitad del ancho: los mismos tamaños de letra se ven la mitad de grandes. Usar el `viewBox` de 800 y no bajar de 20 en ningún texto. El generador avisa si algún texto quedará por debajo de 11 pt en la diapositiva.

## Dibujo

- De 3 a 7 elementos por figura. Si hacen falta más, son dos figuras.
- Líneas y flechas de 3 a 4 de grosor; bordes de 2. Esquinas redondeadas con `rx` de 12 a 16.
- Separación de 20 a 40 entre bloques y relleno interior de 24 o más.
- Numerar los pasos cuando el orden importa.
- Flechas con `<marker>`; no usar caracteres de flecha en el texto.
- No se admiten `<script>`, `<foreignObject>`, imágenes externas, `DOCTYPE` ni entidades. Evitar filtros y sombras.
- Usar atributos de presentación (`fill`, `stroke`) mejor que `style` o CSS.

## Modelos

Cada institución tiene cuatro figuras modelo con su paleta en `marcas/<institucion>/figuras/`. Lo normal es copiar la que más se parezca a lo que hay que dibujar y cambiar textos y elementos, en lugar de empezar de cero.

| Archivo | Qué muestra | `viewBox` |
|---|---|---|
| `proceso.svg` | Tres pasos en fila unidos por flechas, con una nota debajo | 1200 x 420 |
| `ciclo.svg` | Cuatro fases en círculo con flechas curvas y un rótulo central | 1200 x 560 |
| `jerarquia.svg` | Un bloque superior y tres dependientes, con conectores en ángulo recto | 1200 x 470 |
| `matriz.svg` | Cuatro cuadrantes sobre dos ejes rotulados; pensada para ir junto a `puntos` | 800 x 560 |

Así empieza `marcas/unir/figuras/proceso.svg`:

```xml
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 420" font-family="Arial, Helvetica, sans-serif">
  <defs>
    <marker id="punta" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <path d="M0 0L10 5L0 10z" fill="#535353"/>
    </marker>
  </defs>
  <rect x="30" y="110" width="320" height="170" rx="14" fill="#0D61F2"/>
  <text x="190" y="185" text-anchor="middle" font-size="34" font-weight="bold" fill="#FFFFFF">1. Piloto</text>
  <text x="190" y="228" text-anchor="middle" font-size="24" fill="#FFFFFF">Dos facultades</text>
  <line x1="362" y1="195" x2="428" y2="195" stroke="#535353" stroke-width="4" marker-end="url(#punta)"/>
  <!-- ... -->
</svg>
```

## Comprobar

```bash
uv run scripts/figura.py --institucion unir figura.svg figura.png
```

Corregir los errores, atender los avisos y mirar el PNG antes de usar la figura: comprobar que ningún texto se sale de su caja ni se monta sobre otro. En la diapositiva, la figura lleva:

- `descripcion`: el equivalente en texto del diagrama (qué elementos hay y cómo se relacionan), para lectores de pantalla.
- `pie`: «Figura 1. Título de la figura.», numerando las figuras por orden de aparición.
- `nota_fuente` con «Elaboración propia», o `fuentes` si la figura adapta la de una obra, en cuyo caso el pie o la nota dicen «Adaptado de…».
