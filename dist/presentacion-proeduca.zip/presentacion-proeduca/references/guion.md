# Guion y crítica

El guion es una lista numerada con el tipo, el título y la idea de cada diapositiva. Se escribe y se critica antes de la especificación, porque rehacer un guion es barato y rehacer una presentación no.

## Reglas de redacción

- **El título afirma algo.** Dice lo que el público debe retener, no el tema. «Las licencias duplicadas cuestan 120.000 euros al año», no «Costes de licencias». Títulos como «Introducción», «Resultados» o «Próximos pasos» solo valen como antetítulo.
- **El cuerpo prueba el título.** Si se tapa el cuerpo, el título debe seguir entendiéndose; si se tapa el título, el cuerpo debe llevar a él.
- **Una idea por diapositiva.** Si hay dos, son dos diapositivas. Ante un texto que no cabe, primero se parte o se acorta; nunca se aprieta.
- **Leída solo por los títulos, la presentación cuenta la historia completa.** La apertura plantea el problema o la pregunta y el final da la conclusión o la recomendación.
- **Listas de seis puntos como máximo**, con la misma construcción gramatical y una longitud parecida.
- **El mismo término para lo mismo** en toda la presentación, y el mismo que usa la fuente citada.
- **Mayúscula solo en la primera palabra** de títulos y rótulos, y en los nombres propios.
- **Sin palabras de relleno**: «robusto», «potente», «innovador», «clave» y similares no dicen nada si no llevan un dato detrás. Tampoco siglas sin explicar ni atribuciones vagas («los expertos señalan»).
- **Las salvedades y el detalle van en las notas del orador** (`notas`), sobre todo en las diapositivas de datos y en la de conclusiones. Las notas viajan con el archivo: no escribir en ellas nada que no se pueda compartir.

## Números y fórmulas

Se aplican a tablas, cifras, textos y figuras. En los gráficos el formato lo pone el generador con el campo `decimales`.

- **Coma decimal**: `0,746`, no `0.746`. Punto para los millares a partir de cinco cifras: `12.500`; sin separador con cuatro: `2500`.
- **Los mismos decimales** en todos los valores comparables: una columna de tabla, las cifras de una diapositiva, una serie.
- **Sin notación científica**: `8,7e-09` no se lee. Un p-valor muy pequeño se escribe `< 0,001`; una magnitud, `2,3 × 10⁻⁸`.
- **Signo menos tipográfico**: `−0,158`, con «−» (U+2212), no con guion.
- **Unidad y espacio**: `24,5 mpg`, `38 %`, `120.000 €`.
- **Redondear a lo que se puede decir en voz alta**: tres cifras significativas suelen bastar. `232,5` mejor que `232,4871`.
- **Subíndices y superíndices con sus caracteres Unicode**: `β₀ + β₁x`, `R²`, `σ²`, `x₁`, no `β0`, `R2` ni `x1`. Los nombres de variable de un programa (`hp`, `mpg`) se dejan como están.
- **Una fórmula con fracciones, sumatorios o matrices** no cabe en una línea de texto: va como `figura`, o se explica con palabras y se deja la expresión para las notas.

## La forma sigue al contenido

| El contenido es… | Tipo |
|---|---|
| Una afirmación con su explicación | `texto` |
| Elementos paralelos y de igual peso | `columnas` |
| Cantidades que se comparan o evolucionan | `grafico` (columnas o líneas) |
| Relación entre dos variables numéricas | `grafico` (dispersión) |
| Dos a cuatro números que resumen el mensaje | `cifras` |
| Valores cruzados por filas y columnas | `tabla` |
| Pasos o fechas en orden | `cronologia` |
| Relaciones, flujos o estructuras | `figura` |

- No usar columnas para cosas que no son comparables, ni una tabla para lo que es una secuencia.
- No repetir el mismo tipo tres veces seguidas si el contenido admite otro.
- Usar `separador` solo con dos o más secciones y cuando cada sección tenga más de una diapositiva. Con más de ocho diapositivas de contenido, los separadores ayudan.
- El cuerpo de texto de la plantilla es pequeño (13,31 pt): sirve para leer en pantalla propia o en papel. Para proyectar, apoyarse en la entradilla y en los tipos visuales.

## Crítica antes de generar

Releer el guion como lo haría alguien que no conoce el tema y comprobar:

1. ¿Cada título es una afirmación completa que se entiende sola?
2. ¿Se sigue el argumento leyendo solo los títulos?
3. ¿Hay alguna diapositiva con más de una idea, o alguna que no aporte nada al argumento?
4. ¿El tipo elegido corresponde a la forma del contenido?
5. ¿Cada dato y cada afirmación tomada de una obra tiene su fuente? ¿Queda algún dato sin respaldo?
6. ¿Hay algún gráfico o figura con valores puestos para ilustrar y no sacados de datos? Si lo hay, se sustituye por datos reales o se convierte en un esquema declarado como tal.
7. ¿Los números siguen las reglas de formato y llevan los mismos decimales?
8. ¿La primera diapositiva de contenido plantea el problema y la última da la conclusión?

Corregir el guion con lo que salga. Al enseñarlo al usuario, señalar las dos o tres decisiones dudosas en lugar de pedir una aprobación genérica.
