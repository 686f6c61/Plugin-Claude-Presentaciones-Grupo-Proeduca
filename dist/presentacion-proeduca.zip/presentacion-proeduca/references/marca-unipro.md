# Marca UNIPRO en la plantilla

Valores extraídos de la plantilla oficial de UNIPRO (`plantilla_defensa.pptx`). Sirven para explicar la plantilla y para revisar un resultado; no hay que aplicarlos a mano, porque ya están en los diseños.

## Formato

- Diapositiva panorámica de 33,80 x 19,57 cm (12 168 188 x 7 046 913 EMU).
- Un patrón y siete diseños: Portada, Separador marino, Separador azul, Texto, Contenido, Solo logotipo y Cierre.

## Logotipo

- Portada: logotipo en blanco, arriba a la izquierda (8,05 x 1,27 cm, a 1,91 cm del borde izquierdo y 2,27 cm del superior).
- Diapositivas interiores y cierre: logotipo en color, abajo a la izquierda (4,85 x 0,77 cm).
- Los separadores no llevan logotipo.
- El logotipo está incrustado en los diseños en SVG con copia PNG. No se recoloca, no se escala y no se cambia de color.

## Colores

| Uso | Color |
|---|---|
| Fondo de portada y de separador azul; «Muchas» y esquinas del cierre | `#0A5CF5` |
| Fondo de separador marino | `#01224E` |
| Última palabra del cierre | `#FF7475` |
| Antetítulo, cifras destacadas, cabecera de tabla, círculos de la cronología, barra junto al título | `#4472C4` (énfasis 1 del tema) |
| Notas, número de página, eje y líneas del gráfico, línea de la cronología, detalle de las cifras | `#ED7D31` (énfasis 2 del tema) |
| Rótulos de gráfico, iconos de columnas pares, puntos de la cronología | `#5B9BD5` (énfasis 5 del tema) |
| Título, entradilla, texto de cifras, rótulos de columnas pares, primera columna de tabla | `#00566C` |
| Texto de cuerpo y fila de total de la tabla | `#44546A` (texto 2 del tema) |
| Título de cada hito de la cronología | `#219BC3` |
| Filas de tabla | énfasis 2 aclarado al 40 % y al 60 %, alternos |
| Series del gráfico, en orden | `#5B9BD5`, `#4472C4`, `#44546A`, `#ED7D31` |

La portada, los separadores y el cierre usan la paleta de marca de UNIPRO; las diapositivas interiores usan los colores del tema de la plantilla original. Esa mezcla es la del archivo oficial y se conserva tal cual.

## Paleta de las figuras

Las figuras dibujadas en SVG usan la paleta de marca: azul `#0A5CF5`, azul marino `#01224E` y coral `#FF7475`, con los grises `#44546A`, `#A5A5A5` y `#E7E6E6` y el blanco. El script `figura.py --institucion unipro` rechaza cualquier otro color. El detalle está en [figuras.md](figuras.md).

## Tipografías y tamaños

| Elemento | Fuente | Tamaño |
|---|---|---|
| Portada: título | Arial negrita | 71,86 pt |
| Portada: autor | Arial | 27,95 pt |
| Portada: pie | Proeduca Sans Light | 11,98 pt |
| Separador: título | Proeduca Sans Light | 53,90 pt |
| Separador: subtítulo | Proeduca Sans Light | 24,95 pt |
| Separador: número | Proeduca Sans Light | 339,35 pt |
| Título de diapositiva (dos líneas) | Arial negrita | 29,28 pt |
| Entradilla | Arial | 23,95 pt |
| Nota de la entradilla | Arial | 15,97 pt |
| Cuerpo, puntos de lista y descripciones | Arial | 13,31 pt |
| Rótulos de columna, de gráfico y títulos de hito | Arial | 23,95 pt |
| Marca de hito | Arial | 21,29 pt |
| Cifra destacada | Arial negrita | 63,21 pt |
| Texto de cifra | Arial negrita | 29,28 pt |
| Tabla: cabecera y total | negrita | 19 pt |
| Tabla: primera columna | negrita | 16 pt |
| Tabla: celdas | normal | 13 pt |
| Gráfico: etiquetas de datos | negrita | 19,96 pt |
| Gráfico: eje de valores | negrita | 23,95 pt |
| Número de página | Franklin Gothic Medium negrita | 17,97 pt |
| Línea de fuentes al pie | Arial | 11,98 pt |
| Lista de referencias | Arial, sangría francesa de 1,27 cm | 13,31 pt |
| Cierre | Arial negrita | 44 pt |

Proeduca Sans Light es la fuente corporativa y Franklin Gothic suele venir con Microsoft Office. Ninguna está incrustada en el archivo: en un equipo que no las tenga, PowerPoint las sustituye.

## Elementos fijos

- Barra vertical azul a la izquierda del título en las diapositivas con cabecera.
- Número de página abajo a la derecha, con el texto «pág.» y el número en dos cifras, precedido de una barra vertical azul. No aparece en portada, separadores, cifras ni cierre.
- Esquinas azules alrededor del texto del cierre.
