# Marca UNIR en la plantilla

Valores extraídos de la plantilla corporativa de UNIR (`plantilla_corporativa_unir.pptx`). Sirven para explicar la plantilla y para revisar un resultado; no hay que aplicarlos a mano, porque ya están en los diseños.

## Formato

- Diapositiva 16:9 de 67,73 x 38,10 cm (24 384 000 x 13 716 000 EMU). El lienzo es el doble de grande que el habitual, así que los tamaños de letra en puntos son también el doble: 34 pt aquí se ven como 17 pt en una diapositiva corriente.
- Un patrón y nueve diseños: Portada, Separador azul, Separador blanco, Separador negro, Agenda, Texto, Cita, Cifras y Cierre.
- De la plantilla original se han quitado las diapositivas de ejemplo y sus fotografías.

## Logotipo

- Portada y cierre: logotipo horizontal en blanco, arriba a la izquierda, sobre el fondo degradado.
- Separadores azul y negro: logotipo vertical en blanco en el margen izquierdo.
- Las diapositivas de contenido no llevan logotipo, solo el número de página.
- El logotipo y el fondo degradado están incrustados en los diseños. No se recolocan, no se escalan y no se cambian de color.

## Colores

| Uso | Color |
|---|---|
| Títulos, números de sección, marcas de columna, primera serie de los gráficos, fondo del separador azul | `#0D61F2` (énfasis 1 del tema) |
| Cabecera de tabla, etiquetas de datos, segunda serie | `#052761` (énfasis 2) |
| Tercera serie | `#41EBCC` (énfasis 4) |
| Cuarta serie y acento de las figuras | `#E328CC` (énfasis 3) |
| Texto de cuerpo | `#000000` |
| Viñetas, numeración de la agenda y ejes de los gráficos | `#959CAF` |
| Bordes de cajas y de tabla, líneas de división | `#D3D6DE` |
| Fondo de portada, cierre y franja de cifras | degradado azul de la marca (imagen) |

## Tipografías y tamaños

Toda la plantilla usa Arial.

| Elemento | Estilo | Tamaño |
|---|---|---|
| Portada: título | negrita, blanco | 150 pt (110 pt si es largo) |
| Portada: subtítulo a la derecha | negrita, blanco | 80 pt |
| Portada: línea de autor | blanco | 30 pt |
| Separador: número | normal | 120 pt |
| Separador: título | negrita, mayúsculas | 120 pt |
| Título de diapositiva | negrita, mayúsculas, azul | 60 pt |
| Antetítulo (línea bajo el título) | mayúsculas | 24 pt |
| Cuerpo y listas | interlineado 1,5 | 34 pt |
| Cita | negrita, azul | 100 pt (80 pt si es larga) |
| Columnas: marca en la caja | azul | 80 pt |
| Columnas, cifras e hitos: rótulo | negrita, mayúsculas | 34 pt |
| Columnas, cifras e hitos: texto | normal | 28 pt |
| Cifras: valor | negrita, blanco | 60 pt |
| Cifras: etiqueta | mayúsculas, blanco | 18 pt |
| Tabla | normal | 28 pt |
| Gráfico: etiquetas de datos | negrita | 40 pt |
| Gráfico: ejes y leyenda | normal | 28 a 32 pt |
| Lista de referencias | sangría francesa | 28 pt |
| Línea de fuentes y número de página | normal | 16 pt |
| Cierre | negrita, blanco | 180 pt |

## Elementos fijos

- Títulos y rótulos en mayúsculas, como en las diapositivas de muestra de la plantilla. El generador los convierte; en la especificación se escriben con normalidad.
- Número de página abajo a la izquierda, muy pequeño. No aparece en portada ni en cierre.
- La línea de fuentes ocupa el pie que la plantilla reserva para una nota, abajo, alineada con el contenido.
- Comillas grandes azules sobre la cita.
