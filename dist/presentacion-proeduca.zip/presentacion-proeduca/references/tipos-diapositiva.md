# Formato de la especificación

La especificación es un objeto JSON en UTF-8:

```json
{
  "institucion": "unir",
  "titulo": "Título del documento (metadatos, opcional)",
  "autor": "Autor del documento (metadatos, opcional)",
  "diapositivas": [ { "tipo": "portada", "titulo": "..." } ],
  "referencias": { "garcia2024": { "autores": "García y López", "anio": "2024", "referencia": "..." } }
}
```

`institucion` es obligatorio: `"unir"` o `"unipro"`. Decide la plantilla, los tipos disponibles y la paleta de las figuras. Si el usuario no ha dicho para qué institución es la presentación, se le pregunta; no se elige una por defecto.

Cada elemento de `diapositivas` lleva un `tipo` y los campos de ese tipo. Todos los tipos admiten además `notas` (texto para las notas del orador).

Los límites de caracteres son orientativos: el script avisa al superarlos, pero no impide generar. Los límites de número de elementos son obligatorios. Los límites de caracteres están medidos sobre la plantilla de UNIPRO; en UNIR el texto es proporcionalmente algo mayor, así que conviene quedarse un poco por debajo y fiarse de `auditar.py`.

## Diferencias entre instituciones

| | UNIR | UNIPRO |
|---|---|---|
| Tipos propios | `agenda`, `cita` | ninguno |
| Colores de `separador` | `azul` (por defecto), `blanco`, `negro` | `marino` (por defecto), `azul` |
| Títulos y rótulos | el generador los pasa a mayúsculas | se dejan como se escriben |
| `antetitulo` | línea pequeña bajo el título | primera línea del título, en azul |
| `portada` | admite `subtitulo` (texto grande a la derecha); `autor` y `pie` van juntos en la línea inferior | `autor` bajo el título y `pie` abajo |
| `columnas` | caja con un número, o con `marca` (una o dos letras); `icono` se ignora | `icono` opcional |
| `cifras` | admite `titulo` y `antetitulo`, sobre la franja azul; `detalle` va como etiqueta encima de la cifra | sin título; `detalle` va como segunda línea |
| `grafico` | las categorías van en el eje; `descripciones` se ignora | rótulo y descripción bajo cada categoría |
| `cronologia` | cajas numeradas; con más de 4 hitos la marca pasa al rótulo; sin iconos | línea de tiempo con iconos en los extremos |
| `tabla` | cabecera azul marino, filas blancas | cabecera azul, filas naranja alternas, primera columna en negrita |
| `cierre` | `"Gracias"` por defecto | `"Muchas gracias"` por defecto |
| Línea de fuentes | en el pie de la plantilla, 16 pt | junto al logotipo, 11,98 pt |


Los tipos `texto`, `columnas`, `grafico`, `cifras`, `tabla`, `cronologia` y `figura` admiten además la línea de fuentes al pie:

| Campo | Obligatorio | Límite | Descripción |
|---|---|---|---|
| `fuentes` | no | 4 obras | Lista de claves de `referencias`. Al pie sale «Fuentes: García y López (2024); OCDE (2023).» |
| `nota_fuente` | no | 110 | Texto libre que se añade a la línea: «Elaboración propia» |

Los tipos `texto`, `columnas`, `grafico`, `tabla`, `cronologia` y `figura` comparten cabecera y llevan número de página:

| Campo | Obligatorio | Límite | Descripción |
|---|---|---|---|
| `antetitulo` | no | 45 | Primera línea del título, en azul: la sección |
| `titulo` | sí | 45 | Segunda línea del título |

## portada

| Campo | Obligatorio | Límite | Descripción |
|---|---|---|---|
| `titulo` | sí | 45 | Admite `\n` para forzar el salto de línea; dos líneas como máximo |
| `autor` | no | 60 | Nombre de la persona o del equipo |
| `pie` | no | 110 | Línea pequeña inferior, por ejemplo `10/11/26 – Comité de dirección` |

## separador

| Campo | Obligatorio | Límite | Descripción |
|---|---|---|---|
| `titulo` | sí | 40 | Dos líneas como máximo; admite `\n` |
| `subtitulo` | no | 80 | |
| `numero` | no | 2 | Número de sección, por ejemplo `"01"` |
| `color` | no | | `"marino"` (por defecto) o `"azul"` |

El subtítulo tiene posición fija, pensada para un título de dos líneas. Con un título de una línea queda un hueco entre ambos; es el comportamiento de la plantilla.

Numerar los separadores en orden, `"01"`, `"02"`, `"03"`, siempre con dos cifras.

## texto

| Campo | Obligatorio | Límite | Descripción |
|---|---|---|---|
| `entradilla` | no | 140 | Idea principal, en letra grande; dos líneas como máximo |
| `nota` | no | 120 | Aclaración pequeña en naranja a continuación de la entradilla; exige `entradilla` |
| `cuerpo` | no | 6 párrafos, 700 cada uno | Lista de párrafos |
| `lista` | no | 10 puntos, 220 cada uno | Lista de puntos con viñeta, debajo del cuerpo |

Hace falta al menos uno de `entradilla`, `cuerpo` o `lista`. Entre cuerpo y lista no conviene pasar de 1500 caracteres. Sin entradilla, el cuerpo sube a ocupar su sitio.

```json
{"tipo": "texto", "antetitulo": "Punto de partida", "titulo": "Diagnóstico",
 "entradilla": "Los servicios digitales han crecido sin un plan común",
 "nota": "datos de la auditoría interna",
 "cuerpo": ["Primer párrafo.", "Segundo párrafo."]}
```

## columnas

| Campo | Obligatorio | Límite | Descripción |
|---|---|---|---|
| `columnas` | sí | de 2 a 4 | Lista de columnas |

Cada columna:

| Campo | Obligatorio | Límite | Descripción |
|---|---|---|---|
| `rotulo` | sí | 34, 22 o 16 con 2, 3 o 4 columnas | Una sola línea |
| `icono` | no | | `diamante`, `escudo`, `sol`, `lluvia`, `pizarra` o `copa` |
| `puntos` | sí | 6 puntos, 110 cada uno | Con 4 columnas, no más de 4 puntos cortos |

Las columnas alternan dos estilos, como en la plantilla: las impares en azul con viñeta de marca de verificación y las pares en verde azulado con viñeta circular.

## grafico

Gráfico nativo de PowerPoint, editable. Solo con datos reales: los valores salen del material del usuario o de un cálculo hecho sobre sus datos, nunca se inventan para ilustrar.

| Campo | Obligatorio | Límite | Descripción |
|---|---|---|---|
| `grafico` | no | | `"columnas"` (por defecto), `"lineas"` o `"dispersion"` |
| `categorias` | sí, salvo en dispersión | de 1 a 6, 18 cada una | Rótulos del eje horizontal |
| `series` | sí | de 1 a 4 | Ver abajo |
| `descripciones` | no | 90 cada una | Texto bajo cada categoría; si se da, una por categoría |
| `decimales` | recomendado | de 0 a 4 | Número de decimales de etiquetas y eje. Sin él, cada valor sale con los que tenga y quedan desiguales |
| `eje_y` | recomendado | 40 | Título del eje vertical, con la unidad: `"Error (mpg)"` |
| `eje_x` | en dispersión | 40 | Título del eje horizontal |
| `eje_minimo`, `eje_maximo` | no | | Límites del eje vertical |

En columnas y líneas cada serie es `{"nombre": "...", "valores": [números]}`, con tantos valores como categorías. `nombre` es obligatorio cuando hay más de una serie. Los valores son números, no textos: `7.4`, no `"7,4"`; la coma decimal la pone el gráfico.

- **El eje de un gráfico de columnas empieza en cero.** Las columnas se comparan por su altura y un eje recortado exagera las diferencias. Para mostrar diferencias pequeñas entre valores parecidos (4,22 frente a 4,28) no sirve recortar el eje: es mejor una `tabla`, unas `cifras` o un gráfico de `lineas`, que sí admite `eje_minimo`.
- Dar siempre `decimales`, el mismo criterio para todos los valores.
- Dar `eje_y` con la magnitud y la unidad, salvo que el título de la diapositiva ya lo diga sin ambigüedad.

```json
{"tipo": "grafico", "antetitulo": "Propuesta", "titulo": "La aplicación móvil cuadruplica sus usuarios en dos años",
 "categorias": ["2024", "2025", "2026"], "decimales": 1, "eje_y": "Miles de usuarios al mes",
 "series": [{"nombre": "Aula virtual", "valores": [5.2, 6.1, 7.4]},
            {"nombre": "Aplicación móvil", "valores": [1.1, 2.8, 4.9]}],
 "nota_fuente": "Elaboración propia"}
```

### Dispersión

Para nubes de puntos, rectas de regresión, residuos y cualquier relación entre dos variables numéricas. Cada serie es `{"nombre": "...", "puntos": [[x, y], ...]}`, con un máximo de 500 puntos (si hay más, una muestra aleatoria). Una serie con `"linea": true` se dibuja como línea sin puntos: sirve para la recta o la curva ajustada, dando solo los puntos necesarios para trazarla.

Los puntos son observaciones reales y la recta sale del ajuste real. Si no se tienen los datos, no se dibuja una nube inventada: se explica con un esquema (`figura`) que diga en su pie que es un esquema.

```json
{"tipo": "grafico", "grafico": "dispersion", "antetitulo": "Cuarteto de Anscombe", "titulo": "El primer conjunto sí sigue una recta",
 "eje_x": "x", "eje_y": "y", "decimales": 0,
 "series": [{"nombre": "Observaciones", "puntos": [[10, 8.04], [8, 6.95], [13, 7.58]]},
            {"nombre": "Recta ajustada", "linea": true, "puntos": [[4, 5.0], [14, 10.0]]}],
 "fuentes": ["anscombe1973"]}
```

## cifras

Sin título ni número de página, como en la plantilla.

| Campo | Obligatorio | Límite | Descripción |
|---|---|---|---|
| `cifras` | sí | de 2 a 4 | Lista de cifras |

Cada cifra:

| Campo | Obligatorio | Límite | Descripción |
|---|---|---|---|
| `valor` | sí | 7 | La cifra, con su unidad: `"38 %"`, `"24 h"` |
| `texto` | sí | 34 | Qué mide |
| `detalle` | no | 34 | Segunda línea, en naranja: periodo o matiz |

## tabla

| Campo | Obligatorio | Límite | Descripción |
|---|---|---|---|
| `cabecera` | sí | de 2 a 6 columnas, 16 cada una | Títulos de columna |
| `filas` | sí | de 1 a 8 | Cada fila es una lista con una celda por columna; 22 caracteres por celda |
| `total` | no | | Fila final destacada, con una celda por columna |

Entre cabecera, filas y total no puede haber más de 9 filas. La primera columna va en negrita: usarla para el nombre de cada fila. Una tabla corta se centra en vertical en el área de contenido.

Las celdas son textos: los números se escriben ya formateados, siguiendo las reglas de [guion.md](guion.md#números-y-fórmulas). Todos los valores de una columna, con los mismos decimales.

## cronologia

| Campo | Obligatorio | Límite | Descripción |
|---|---|---|---|
| `hitos` | sí | de 3 a 6 | Lista de hitos, en orden |
| `icono_inicio` | no | | Icono del círculo izquierdo; por defecto `pizarra` |
| `icono_fin` | no | | Icono del círculo derecho; por defecto `copa` |

Cada hito:

| Campo | Obligatorio | Límite | Descripción |
|---|---|---|---|
| `marca` | no | 8 | Hora, fecha o fase, sobre la línea: `"11:00"`, `"Mar"` |
| `titulo` | sí | 22, 16, 12 o 10 con 3, 4, 5 o 6 hitos | Una sola línea |
| `texto` | no | ocho veces el límite del título | Descripción breve |

## cierre

| Campo | Obligatorio | Límite | Descripción |
|---|---|---|---|
| `texto` | no | 16 | Por defecto `"Muchas gracias"`. La última palabra va en coral |

Las esquinas decorativas están ajustadas a «Muchas gracias»; un texto más largo se sale de ellas.

## figura

| Campo | Obligatorio | Límite | Descripción |
|---|---|---|---|
| `imagen` | sí | | Ruta de un archivo `.svg`, `.png` o `.jpg`, relativa a la carpeta de la especificación |
| `pie` | no | 110 | Pie centrado bajo la figura: «Figura 1. Fases del despliegue.» |
| `descripcion` | recomendado | 300 | Texto alternativo: qué muestra la figura, para lectores de pantalla |
| `puntos` | no | 6 puntos, 110 cada uno | Lista a la izquierda; la figura pasa a ocupar la mitad derecha |

Un `.svg` se comprueba y se convierte a PNG al generar; si usa colores fuera de la paleta de la institución, la generación se detiene. Las reglas de dibujo están en [figuras.md](figuras.md). Un PNG o JPG debe tener al menos 1200 píxeles de ancho.

```json
{"tipo": "figura", "antetitulo": "Propuesta", "titulo": "El despliegue avanza en tres pasos",
 "imagen": "proceso.svg", "pie": "Figura 1. Fases del despliegue del plan.",
 "descripcion": "Tres cajas unidas por flechas: piloto, despliegue y balance.",
 "nota_fuente": "Elaboración propia"}
```

## Referencias y citas APA

`referencias` es un objeto en la raíz de la especificación. Cada clave identifica una obra:

| Campo | Obligatorio | Descripción |
|---|---|---|
| `autores` | sí | Autores tal como van en la cita breve: `"García"`, `"García y López"`, `"García et al."`, `"OCDE"` |
| `anio` | sí | Año de la cita: `"2024"`, `"2024a"`, `"s. f."` |
| `referencia` | sí | La referencia completa en formato APA 7. El texto entre asteriscos sale en cursiva |

Cada diapositiva que use una obra la nombra en `fuentes`. Con eso el generador:

1. escribe al pie de la diapositiva la cita breve, «Fuente: García y López (2024).»;
2. añade antes del cierre la diapositiva «Referencias» con las obras citadas, por orden alfabético y con sangría francesa, repartida en varias diapositivas si hace falta.

Solo salen en la lista las obras citadas en alguna diapositiva; el script avisa de las que sobran. Una clave de `fuentes` que no esté en `referencias` es un error.

Formato APA 7 de las obras más habituales, con la cursiva marcada con asteriscos:

| Obra | Formato |
|---|---|
| Libro | `Apellido, N. (2024). *Título del libro* (2.ª ed.). Editorial.` |
| Capítulo | `Apellido, N. (2024). Título del capítulo. En N. Apellido (Ed.), *Título del libro* (pp. 12-34). Editorial.` |
| Artículo | `Apellido, N., y Apellido, N. (2024). Título del artículo. *Nombre de la Revista*, *12*(3), 45-67. https://doi.org/...` |
| Informe | `Organismo. (2024). *Título del informe*. https://...` |
| Página web | `Apellido, N. (2024, 5 de marzo). *Título de la página*. Nombre del sitio. https://...` |
| Tesis | `Apellido, N. (2024). *Título* [Trabajo de fin de máster, Universidad]. Repositorio. https://...` |
| Programa | `Autor. (2026). *Nombre* [Software]. GitHub. https://...` |

Reglas que conviene recordar: hasta veinte autores se escriben todos, con «y» antes del último; en la cita breve, tres o más autores se abrevian con «et al.»; sin fecha se pone «s. f.»; dos obras del mismo autor y año se distinguen con «2024a» y «2024b»; el título va con mayúscula solo en la primera palabra.

No completar con suposiciones los datos bibliográficos que falten: pedirlos al usuario o consultar la fuente.

## referencias

Solo hace falta incluir esta diapositiva para cambiar la posición o el título de la lista; si no aparece y hay obras citadas, el generador la añade antes del cierre.

| Campo | Obligatorio | Límite | Descripción |
|---|---|---|---|
| `titulo` | no | 45 | Por defecto `"Referencias"` |
| `antetitulo` | no | 45 | |

## agenda

Solo en UNIR.

| Campo | Obligatorio | Límite | Descripción |
|---|---|---|---|
| `puntos` | sí | de 1 a 8, 70 cada uno | Se numeran solos |
| `titulo` | no | 45 | Por defecto `"Agenda"` |
| `antetitulo` | no | 60 | Línea pequeña bajo el título |

```json
{"tipo": "agenda", "antetitulo": "Comité de dirección",
 "puntos": ["Punto de partida", "Análisis", "Propuesta y presupuesto", "Calendario"]}
```

## cita

Solo en UNIR. Una frase a toda la diapositiva, en azul, bajo unas comillas grandes.

| Campo | Obligatorio | Límite | Descripción |
|---|---|---|---|
| `texto` | sí | 190 | La frase, sin comillas. Con más de 120 caracteres baja de tamaño |
| `autor` | no | 70 | Sale debajo, precedido de una raya |

Una cita textual de una obra lleva la obra en `fuentes`; una frase propia, `nota_fuente`.
