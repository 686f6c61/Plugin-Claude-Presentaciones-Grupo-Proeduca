#!/usr/bin/env python3
# Creado por 686f6c61.dev (https://686f6c61.dev)
# /// script
# requires-python = ">=3.10"
# dependencies = ["python-pptx>=1.0"]
# ///
"""Audita una presentación generada, sin necesidad de LibreOffice.

Uso:
    uv run auditar.py PRESENTACION.pptx

Estima cuánto ocupa cada texto a partir de su fuente, tamaño y ancho de caja, y
avisa de:
  - formas o textos que se salen de la diapositiva;
  - textos que invaden la zona del pie (logotipo, fuentes y número de página);
  - textos que se montan sobre otra forma;
  - celdas de tabla cuyo texto no cabe en una línea;
  - restos de texto de ejemplo y marcadores vacíos;
  - el mismo tipo de diapositiva tres o más veces seguidas;
  - diapositivas con datos (gráfico, tabla, cifras) sin línea de fuente.

La estimación es aproximada: no sustituye a la revisión visual, la complementa.
Código de salida: 0 sin avisos, 1 con avisos.
"""

import math
import re
import sys
from pathlib import Path

from pptx import Presentation

A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
P = "{http://schemas.openxmlformats.org/presentationml/2006/main}"

# Medidas de cada plantilla, que se reconoce por el ancho de la diapositiva.
#   pie: por debajo empieza la zona de logotipo, fuentes y número de página
#   con_pie: diseños en los que esa zona existe
PLANTILLAS = {
    12168188: {"nombre": "UNIPRO", "pie": 6200000, "tolerancia": 40000,
               "con_pie": ("Texto", "Contenido", "Solo logotipo")},
    24384000: {"nombre": "UNIR", "pie": 12850000, "tolerancia": 80000,
               "con_pie": ("Texto", "Agenda", "Cita", "Cifras")},
}
PIE_Y = 6200000
TOLERANCIA = 40000
FORMAS_DE_PIE = ("Número de página", "Fuentes", "Subtítulo")
URI_GRAFICO = "http://schemas.openxmlformats.org/drawingml/2006/chart"
SIN_REPETICION = ("referencias",)   # la lista de referencias ocupa las diapositivas que necesite
RESTOS = re.compile(r"(?i:lorem|ipsum|\bxxx+\b|haga clic|click to|insert (divider|subheading))|\bTODO\b")

ESTRECHOS = set("iljtfrI.,;:'|!()[] ")
ANCHOS = set("mwMW@%")


def ancho_texto(texto, puntos, negrita):
    """Ancho aproximado en EMU de una línea de texto en Arial."""
    em = 0.0
    for c in texto:
        if c in ESTRECHOS:
            em += 0.30
        elif c in ANCHOS:
            em += 0.86
        elif c.isupper():
            em += 0.68
        elif c.isdigit():
            em += 0.56
        else:
            em += 0.53
    return em * puntos * (1.06 if negrita else 1.0) * 12700


def _entero(el, atributo, defecto=None):
    valor = el.get(atributo) if el is not None else None
    return int(valor) if valor is not None else defecto


class Caja:
    def __init__(self, nombre, x, y, cx, cy, texto="", es_texto=False):
        self.nombre, self.x, self.y, self.cx, self.cy = nombre, x, y, cx, cy
        self.texto, self.es_texto = texto, es_texto

    @property
    def derecha(self):
        return self.x + self.cx

    @property
    def abajo(self):
        return self.y + self.cy

    def etiqueta(self):
        resumen = self.texto.strip().replace("\n", " ")
        if len(resumen) > 34:
            resumen = resumen[:33] + "…"
        return f"«{self.nombre}»" + (f" ({resumen})" if resumen else "")

    def solapa(self, otra):
        ancho = min(self.derecha, otra.derecha) - max(self.x, otra.x)
        alto = min(self.abajo, otra.abajo) - max(self.y, otra.y)
        return ancho > TOLERANCIA and alto > TOLERANCIA


def marcador_de_diseno(forma, diseno):
    ph = forma.find(f"{P}nvSpPr/{P}nvPr/{P}ph")
    if ph is None:
        return None
    idx, tipo = ph.get("idx"), ph.get("type")
    for candidato in diseno.iter(f"{P}sp"):
        otro = candidato.find(f"{P}nvSpPr/{P}nvPr/{P}ph")
        if otro is None:
            continue
        if idx is not None and otro.get("idx") == idx:
            return candidato
        if idx is None and otro.get("idx") is None and (otro.get("type") or "body")[-5:] == (tipo or "body")[-5:]:
            return candidato
    return None


def estilo_del_patron(patron, es_titulo):
    """Tamaño e interlineado por defecto del patrón, para los marcadores cuyo
    diseño no los fija."""
    estilos = patron.find(f"{P}txStyles")
    nivel = estilos.find(f"{P}{'titleStyle' if es_titulo else 'bodyStyle'}/{A}lvl1pPr") if estilos is not None else None
    if nivel is None:
        return 1815, 100000
    tam = _entero(nivel.find(f"{A}defRPr"), "sz", 1815)
    interlineado = _entero(nivel.find(f"{A}lnSpc/{A}spcPct"), "val", 100000)
    return tam, interlineado


def caja_de_texto(forma, heredada, patron=None):
    """Rectángulo estimado que ocupa el texto de una forma."""
    fuentes = [f for f in (forma, heredada) if f is not None]
    xfrm = next((f.find(f"{P}spPr/{A}xfrm") for f in fuentes if f.find(f"{P}spPr/{A}xfrm") is not None), None)
    if xfrm is None:
        return None
    off, ext = xfrm.find(f"{A}off"), xfrm.find(f"{A}ext")
    x, y, cx, cy = int(off.get("x")), int(off.get("y")), int(ext.get("cx")), int(ext.get("cy"))

    def propiedad(ruta, atributo, defecto):
        for f in fuentes:
            valor = _entero(f.find(ruta), atributo)
            if valor is not None:
                return valor
        return defecto

    cuerpo = f"{P}txBody/{A}bodyPr"
    margen_izq, margen_der = propiedad(cuerpo, "lIns", 91440), propiedad(cuerpo, "rIns", 91440)
    margen_sup, margen_inf = propiedad(cuerpo, "tIns", 45720), propiedad(cuerpo, "bIns", 45720)
    ancla = next((f.find(cuerpo).get("anchor") for f in fuentes
                  if f.find(cuerpo) is not None and f.find(cuerpo).get("anchor")), "t")
    nivel1 = f"{P}txBody/{A}lstStyle/{A}lvl1pPr"
    ph = forma.find(f"{P}nvSpPr/{P}nvPr/{P}ph")
    tam_patron, interlineado_patron = 1815, 100000
    if ph is not None and patron is not None:
        tam_patron, interlineado_patron = estilo_del_patron(patron, (ph.get("type") or "").endswith("itle"))
    tam_base = propiedad(f"{nivel1}/{A}defRPr", "sz", tam_patron)
    # Las fuentes finas (Proeduca Sans Light) son más estrechas que Arial.
    fuente = next((f.find(f"{nivel1}/{A}defRPr/{A}latin").get("typeface") for f in fuentes
                   if f.find(f"{nivel1}/{A}defRPr/{A}latin") is not None), "Arial")
    estrechez = 0.88 if "Light" in fuente else 1.0
    interlineado_base = propiedad(f"{nivel1}/{A}lnSpc/{A}spcPct", "val", interlineado_patron)
    negrita_base = propiedad(f"{nivel1}/{A}defRPr", "b", 0)
    sangria_base = propiedad(nivel1, "marL", 0)
    tras_base = propiedad(f"{nivel1}/{A}spcAft/{A}spcPts", "val", 0)
    alineacion_base = next((f.find(nivel1).get("algn") for f in fuentes
                            if f.find(nivel1) is not None and f.find(nivel1).get("algn")), "l")

    nombre = forma.find(f"{P}nvSpPr/{P}cNvPr").get("name")
    alto, ancho_max, lineas_total, textos, alineacion = margen_sup + margen_inf, 0, 0, [], alineacion_base
    for p in forma.findall(f"{P}txBody/{A}p"):
        ppr = p.find(f"{A}pPr")
        sangria = _entero(ppr, "marL", sangria_base)
        tras = _entero(ppr.find(f"{A}spcAft/{A}spcPts") if ppr is not None else None, "val", tras_base)
        tras += _entero(ppr.find(f"{A}spcBef/{A}spcPts") if ppr is not None else None, "val", 0)
        interlineado = 1.2 * _entero(ppr.find(f"{A}lnSpc/{A}spcPct") if ppr is not None else None,
                                     "val", interlineado_base) / 100000
        if ppr is not None and ppr.get("algn"):
            alineacion = ppr.get("algn")
        disponible = max(cx - margen_izq - margen_der - sangria, 100000)
        # Cada salto de línea manual abre un tramo que se ajusta por separado.
        tramos, actual, tam_parrafo = [], [], tam_base
        for hijo in p:
            etiqueta = hijo.tag.split("}")[1]
            if etiqueta in ("r", "fld"):
                rpr = hijo.find(f"{A}rPr")
                tam = _entero(rpr, "sz", tam_base)
                negrita = _entero(rpr, "b", negrita_base)
                tam_parrafo = max(tam_parrafo, tam) if actual else tam
                actual.append(((hijo.find(f"{A}t").text or ""), tam, negrita))
            elif etiqueta == "br":
                tramos.append(actual)
                actual = []
        tramos.append(actual)
        for tramo in tramos:
            if not tramo:
                continue
            ancho = estrechez * sum(ancho_texto(t, tam / 100, negrita) for t, tam, negrita in tramo)
            lineas = max(1, math.ceil(ancho * 1.06 / disponible))
            if " " not in "".join(t for t, _, _ in tramo).strip():
                lineas = 1                      # una sola palabra no se parte
            tam_linea = max(tam for _, tam, _ in tramo)
            alto += lineas * tam_linea / 100 * interlineado * 12700
            lineas_total += lineas
            ancho_max = max(ancho_max, min(ancho, disponible) + sangria)
            textos.append("".join(t for t, _, _ in tramo))
        if any(tramos):
            alto += tras * 127
    if not textos:
        return None
    alto = int(alto)
    if ancla == "b":
        y = y + cy - alto
    elif ancla == "ctr":
        y = y + (cy - alto) // 2
    ancho_real = int(ancho_max + margen_izq + margen_der)
    if ancho_real < cx:                    # el texto no llena la caja: se ciñe a su alineación
        if alineacion == "ctr":
            x += (cx - ancho_real) // 2
        elif alineacion == "r":
            x += cx - ancho_real
        cx = ancho_real
    return Caja(nombre, x, y, cx, alto, " ".join(textos), es_texto=True)


def tipo_de(diapositiva, cajas):
    """Clasifica la diapositiva para detectar repeticiones."""
    nombres = [c.nombre for c in cajas]
    if any(n.startswith("Cifra ") for n in nombres):
        return "cifras"
    if "Tabla" in nombres:
        return "tabla"
    if any(n.startswith("Chart") or n.startswith("Gráfico") for n in nombres):
        return "grafico"
    if any(n.startswith(("Punto hito", "Caja hito")) for n in nombres):
        return "cronologia"
    if "Figura" in nombres:
        return "figura"
    if any(n.startswith(("Rótulo columna", "Caja columna")) for n in nombres):
        return "columnas"
    if "Lista de referencias" in nombres:
        return "referencias"
    return diapositiva.slide_layout.name.lower()


def auditar(ruta):
    global PIE_Y, TOLERANCIA
    prs = Presentation(str(ruta))
    ancho_diapo, alto_diapo = prs.slide_width, prs.slide_height
    plantilla = PLANTILLAS.get(ancho_diapo, PLANTILLAS[12168188])
    PIE_Y, TOLERANCIA = plantilla["pie"], plantilla["tolerancia"]
    avisos, tipos = [], []
    for n, diapositiva in enumerate(prs.slides, 1):
        def aviso(mensaje):
            avisos.append(f"diapositiva {n}: {mensaje}")

        diseno = diapositiva.slide_layout._element
        con_pie = diapositiva.slide_layout.name in plantilla["con_pie"]
        patron = diapositiva.slide_layout.slide_master._element
        cajas = []
        arbol = diapositiva.shapes._spTree
        for el in arbol:
            etiqueta = el.tag.split("}")[1]
            if etiqueta == "sp":
                nombre = el.find(f"{P}nvSpPr/{P}cNvPr").get("name")
                heredada = marcador_de_diseno(el, diseno)
                texto = "".join(t.text or "" for t in el.iter(f"{A}t")).strip()
                if el.find(f"{P}nvSpPr/{P}nvPr/{P}ph") is not None and not texto:
                    aviso(f"el marcador «{nombre}» está vacío")
                    continue
                if texto and RESTOS.search(texto):
                    aviso(f"«{nombre}» contiene texto de ejemplo: {texto[:40]!r}")
                caja = caja_de_texto(el, heredada, patron) if texto else None
                if caja is None:
                    xfrm = el.find(f"{P}spPr/{A}xfrm")
                    if xfrm is None:
                        continue
                    off, ext = xfrm.find(f"{A}off"), xfrm.find(f"{A}ext")
                    caja = Caja(nombre, int(off.get("x")), int(off.get("y")), int(ext.get("cx")), int(ext.get("cy")))
                cajas.append(caja)
            elif etiqueta in ("pic", "graphicFrame", "cxnSp"):
                nv = el[0].find(f"{P}cNvPr")
                xfrm = el.find(f"{P}xfrm") if etiqueta == "graphicFrame" else el.find(f"{P}spPr/{A}xfrm")
                if xfrm is None:
                    continue
                off, ext = xfrm.find(f"{A}off"), xfrm.find(f"{A}ext")
                alto = int(ext.get("cy"))
                if el.find(f".//{A}graphicData[@uri='{URI_GRAFICO}']") is not None:
                    alto = int(alto * 0.87)      # bajo el área de trazado van los rótulos
                cajas.append(Caja(nv.get("name"), int(off.get("x")), int(off.get("y")), int(ext.get("cx")), alto))
                tabla = el.find(f".//{A}tbl")
                if tabla is not None:
                    anchos = [int(g.get("w")) for g in tabla.find(f"{A}tblGrid")]
                    for f, fila in enumerate(tabla.findall(f"{A}tr"), 1):
                        for c, celda in enumerate(fila.findall(f"{A}tc")):
                            texto = "".join(t.text or "" for t in celda.iter(f"{A}t"))
                            rpr = celda.find(f".//{A}rPr")
                            necesario = ancho_texto(texto, _entero(rpr, "sz", 1300) / 100, _entero(rpr, "b", 0))
                            margenes = _entero(celda.find(f"{A}tcPr"), "marL", 91440) + _entero(celda.find(f"{A}tcPr"), "marR", 91440)
                            if necesario * 1.06 > anchos[c] - margenes:
                                aviso(f"tabla, fila {f}, columna {c + 1}: «{texto}» no cabe en una línea")

        tipos.append(tipo_de(diapositiva, cajas))
        contenido = [c for c in cajas if c.nombre not in FORMAS_DE_PIE]
        for caja in contenido:
            if (caja.x < -TOLERANCIA or caja.y < -TOLERANCIA
                    or caja.derecha > ancho_diapo + TOLERANCIA or caja.abajo > alto_diapo + TOLERANCIA):
                aviso(f"{caja.etiqueta()} se sale de la diapositiva")
            elif con_pie and caja.es_texto and caja.abajo > PIE_Y + TOLERANCIA:
                aviso(f"{caja.etiqueta()} invade la zona del pie: acorta el texto o repártelo en dos diapositivas")
        for i, una in enumerate(contenido):
            for otra in contenido[i + 1:]:
                if not (una.es_texto or otra.es_texto) or not una.solapa(otra):
                    continue
                # Un icono o un punto dentro de su círculo, o la línea de tiempo, se cruzan a propósito.
                if any(clave in (una.nombre + otra.nombre) for clave in ("Círculo", "Línea", "Caja")):
                    continue
                aviso(f"{una.etiqueta()} se monta sobre {otra.etiqueta()}")
        if tipos[-1] in ("grafico", "tabla", "cifras") and not any(c.nombre == "Fuentes" for c in cajas):
            aviso(f"diapositiva de datos ({tipos[-1]}) sin línea de fuente: añade \"fuentes\" o \"nota_fuente\"")

    for i in range(2, len(tipos)):
        if tipos[i] not in SIN_REPETICION and tipos[i] == tipos[i - 1] == tipos[i - 2] and (i == len(tipos) - 1 or tipos[i + 1] != tipos[i]):
            inicio = i
            while inicio > 0 and tipos[inicio - 1] == tipos[i]:
                inicio -= 1
            avisos.append(f"diapositivas {inicio + 1} a {i + 1}: {i - inicio + 1} seguidas del tipo "
                          f"«{tipos[i]}»; alterna con otro tipo si el contenido lo permite")
    return avisos, len(tipos)


def main(argv):
    if len(argv) != 2:
        print(__doc__, file=sys.stderr)
        return 2
    ruta = Path(argv[1])
    if not ruta.is_file():
        print(f"[!] No existe {ruta}", file=sys.stderr)
        return 2
    avisos, total = auditar(ruta)
    for aviso in avisos:
        print(f"[*] {aviso}")
    if avisos:
        print(f"[!] {len(avisos)} aviso(s) en {total} diapositivas. Son estimaciones: confírmalos en la revisión visual.")
        return 1
    print(f"[OK] {ruta.name}: {total} diapositivas sin avisos")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
