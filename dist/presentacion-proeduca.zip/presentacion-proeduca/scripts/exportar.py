#!/usr/bin/env python3
# Creado por 686f6c61.dev (https://686f6c61.dev)
# /// script
# requires-python = ">=3.10"
# dependencies = ["python-pptx>=1.0", "pymupdf>=1.24"]
# ///
"""Exporta una presentación a PDF y a HTML.

Uso:
    uv run exportar.py PRESENTACION.pptx [--pdf] [--html] [--salida CARPETA]

Sin --pdf ni --html genera los dos. Los archivos se llaman como la presentación
y quedan junto a ella, o en CARPETA.

  - PDF: una página por diapositiva.
  - HTML: un único archivo autocontenido, con las diapositivas como imágenes,
    navegación con el teclado, texto alternativo y notas del orador. Se abre en
    cualquier navegador, sin conexión.

Necesita LibreOffice (soffice). Si no está disponible sale con código 3.
El PDF y el HTML los dibuja LibreOffice: si el equipo no tiene las fuentes de la
plantilla, usan fuentes sustitutas y pueden diferir un poco de PowerPoint.
"""

import base64
import html
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ANCHO_IMAGEN = 1600


PERFIL_ES = (
    '<?xml version="1.0" encoding="UTF-8"?>'
    '<oor:items xmlns:oor="http://openoffice.org/2001/registry">'
    '<item oor:path="/org.openoffice.Setup/L10N">'
    '<prop oor:name="ooSetupSystemLocale" oor:op="fuse"><value>es-ES</value></prop></item>'
    "</oor:items>"
)


def perfil_espanol(carpeta):
    """Crea un perfil de LibreOffice con configuración regional española, para
    que los decimales de los gráficos salgan con coma en cualquier equipo."""
    usuario = Path(carpeta) / "perfil" / "user"
    usuario.mkdir(parents=True, exist_ok=True)
    (usuario / "registrymodifications.xcu").write_text(PERFIL_ES, encoding="utf-8")
    return f"-env:UserInstallation=file://{carpeta}/perfil"


def a_pdf(pptx, carpeta):
    """Convierte el .pptx a PDF con LibreOffice; devuelve la ruta o None."""
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if not soffice:
        return None
    resultado = subprocess.run(
        [soffice, "--headless", perfil_espanol(carpeta),
         "--convert-to", "pdf", "--outdir", str(carpeta), str(pptx)],
        capture_output=True, text=True, timeout=300,
    )
    pdf = Path(carpeta) / (pptx.stem + ".pdf")
    if not pdf.is_file():
        raise RuntimeError("LibreOffice no ha generado el PDF. " + resultado.stderr.strip())
    return pdf


def textos_de(pptx):
    """Por cada diapositiva: (título, texto completo, notas)."""
    from pptx import Presentation

    prs = Presentation(str(pptx))
    datos = []
    for diapositiva in prs.slides:
        trozos = []
        for forma in diapositiva.shapes:
            if forma.has_text_frame and forma.name != "Número de página":
                texto = " ".join(p.text.replace("\v", " ") for p in forma.text_frame.paragraphs if p.text.strip())
                if texto:
                    trozos.append(texto)
            elif getattr(forma, "has_table", False) and forma.has_table:
                for fila in forma.table.rows:
                    trozos.append(" | ".join(c.text for c in fila.cells))
            elif forma.shape_type == 13:        # imagen: su texto alternativo
                descripcion = forma._element.nvPicPr.cNvPr.get("descr")
                if descripcion:
                    trozos.append("Figura: " + descripcion)
        # En las diapositivas con cabecera el salto separa antetítulo y título.
        union = " – " if diapositiva.slide_layout.name in ("Texto", "Contenido") else " "
        titulo = diapositiva.shapes.title.text.replace("\v", union) if diapositiva.shapes.title is not None else ""
        notas = ""
        if diapositiva.has_notes_slide:
            notas = diapositiva.notes_slide.notes_text_frame.text.strip()
        datos.append((titulo.strip(), " ".join(trozos), notas))
    return datos, (prs.core_properties.title or pptx.stem)


PAGINA = """<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{titulo}</title>
<style>
  :root {{ --fondo: #f1f2f4; --panel: #ffffff; --texto: #1f2933; --suave: #5b6672; --borde: #d5d9de; --acento: #0a5cf5; }}
  @media (prefers-color-scheme: dark) {{
    :root {{ --fondo: #15181c; --panel: #1f2329; --texto: #e8eaed; --suave: #a3abb5; --borde: #343a42; --acento: #6f9dff; }}
  }}
  * {{ box-sizing: border-box; }}
  body {{ margin: 0; background: var(--fondo); color: var(--texto); font: 16px/1.5 Arial, Helvetica, sans-serif; }}
  header {{ display: flex; flex-wrap: wrap; gap: 8px 16px; align-items: center; justify-content: space-between;
            padding: 12px 16px; border-bottom: 1px solid var(--borde); background: var(--panel); position: sticky; top: 0; z-index: 2; }}
  h1 {{ font-size: 1rem; margin: 0; font-weight: 600; }}
  .controles {{ display: flex; gap: 8px; align-items: center; }}
  button {{ font: inherit; color: var(--texto); background: var(--panel); border: 1px solid var(--borde);
            border-radius: 6px; padding: 6px 12px; cursor: pointer; min-height: 36px; }}
  button:hover {{ border-color: var(--acento); }}
  button:focus-visible {{ outline: 2px solid var(--acento); outline-offset: 2px; }}
  #contador {{ color: var(--suave); min-width: 5.5em; text-align: center; font-variant-numeric: tabular-nums; }}
  main {{ max-width: 1280px; margin: 0 auto; padding: 16px; }}
  section {{ margin: 0 0 24px; }}
  section img {{ display: block; width: 100%; height: auto; border: 1px solid var(--borde); border-radius: 4px; background: #fff; }}
  .pie {{ display: flex; gap: 12px; align-items: baseline; color: var(--suave); font-size: .875rem; margin-top: 6px; }}
  details {{ margin-top: 6px; color: var(--suave); font-size: .875rem; }}
  details p {{ margin: 6px 0 0; color: var(--texto); white-space: pre-wrap; }}
  body.una section {{ display: none; }}
  body.una section.actual {{ display: block; }}
  @media print {{
    header, details, .pie {{ display: none; }}
    body {{ background: #fff; }} main {{ padding: 0; max-width: none; }}
    body.una section {{ display: block; }}
    section {{ margin: 0; page-break-after: always; }} section img {{ border: 0; }}
  }}
</style>
</head>
<body class="una">
<header>
  <h1>{titulo}</h1>
  <div class="controles">
    <button id="anterior" aria-label="Diapositiva anterior">Anterior</button>
    <span id="contador" aria-live="polite"></span>
    <button id="siguiente" aria-label="Diapositiva siguiente">Siguiente</button>
    <button id="modo" aria-pressed="false">Ver todas</button>
  </div>
</header>
<main>
{secciones}
</main>
<script>
  const secciones = [...document.querySelectorAll("section")];
  const contador = document.getElementById("contador");
  const modo = document.getElementById("modo");
  let actual = 0;
  function mostrar(n) {{
    actual = Math.max(0, Math.min(secciones.length - 1, n));
    secciones.forEach((s, i) => s.classList.toggle("actual", i === actual));
    contador.textContent = (actual + 1) + " de " + secciones.length;
  }}
  document.getElementById("anterior").onclick = () => mostrar(actual - 1);
  document.getElementById("siguiente").onclick = () => mostrar(actual + 1);
  modo.onclick = () => {{
    const una = document.body.classList.toggle("una");
    modo.textContent = una ? "Ver todas" : "Ver de una en una";
    modo.setAttribute("aria-pressed", String(!una));
    if (!una) secciones[actual].scrollIntoView();
  }};
  document.addEventListener("keydown", (e) => {{
    if (!document.body.classList.contains("una")) return;
    if (["ArrowRight", "PageDown", " "].includes(e.key)) {{ e.preventDefault(); mostrar(actual + 1); }}
    if (["ArrowLeft", "PageUp"].includes(e.key)) {{ e.preventDefault(); mostrar(actual - 1); }}
    if (e.key === "Home") mostrar(0);
    if (e.key === "End") mostrar(secciones.length - 1);
  }});
  mostrar(0);
</script>
</body>
</html>
"""


def a_html(pdf, pptx, destino):
    import pymupdf

    datos, titulo = textos_de(pptx)
    secciones = []
    with pymupdf.open(str(pdf)) as documento:
        for i, pagina in enumerate(documento):
            escala = ANCHO_IMAGEN / pagina.rect.width
            png = pagina.get_pixmap(matrix=pymupdf.Matrix(escala, escala)).tobytes("png")
            nombre, texto, notas = datos[i] if i < len(datos) else ("", "", "")
            alternativo = html.escape(texto or f"Diapositiva {i + 1}", quote=True)
            bloque_notas = (
                f"<details><summary>Notas del orador</summary><p>{html.escape(notas)}</p></details>" if notas else ""
            )
            secciones.append(
                f'<section id="d{i + 1}" aria-label="Diapositiva {i + 1}">'
                f'<img alt="{alternativo}" src="data:image/png;base64,{base64.b64encode(png).decode()}">'
                f'<div class="pie"><span>{i + 1}</span><span>{html.escape(nombre)}</span></div>'
                f"{bloque_notas}</section>"
            )
    destino.write_text(
        PAGINA.format(titulo=html.escape(titulo), secciones="\n".join(secciones)), encoding="utf-8"
    )
    return len(secciones)


def main(argv):
    args = argv[1:]
    quiere_pdf, quiere_html = "--pdf" in args, "--html" in args
    if not quiere_pdf and not quiere_html:
        quiere_pdf = quiere_html = True
    carpeta = None
    if "--salida" in args:
        i = args.index("--salida")
        if i + 1 >= len(args):
            print("[!] --salida necesita una carpeta", file=sys.stderr)
            return 2
        carpeta = Path(args[i + 1])
        del args[i:i + 2]
    rutas = [a for a in args if not a.startswith("--")]
    if len(rutas) != 1:
        print(__doc__, file=sys.stderr)
        return 2
    pptx = Path(rutas[0]).resolve()
    if not pptx.is_file():
        print(f"[!] No existe {pptx}", file=sys.stderr)
        return 1
    carpeta = (carpeta or pptx.parent).resolve()
    carpeta.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory() as tmp:
        try:
            pdf = a_pdf(pptx, Path(tmp))
        except (RuntimeError, subprocess.TimeoutExpired) as e:
            print(f"[!] {e}", file=sys.stderr)
            return 1
        if pdf is None:
            print("[!] LibreOffice no está instalado: no se puede exportar a PDF ni a HTML.", file=sys.stderr)
            return 3
        if quiere_html:
            destino = carpeta / (pptx.stem + ".html")
            n = a_html(pdf, pptx, destino)
            print(f"[OK] {destino} ({n} diapositivas, {destino.stat().st_size // 1024} KB)")
        if quiere_pdf:
            destino = carpeta / (pptx.stem + ".pdf")
            shutil.copyfile(pdf, destino)
            print(f"[OK] {destino}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
