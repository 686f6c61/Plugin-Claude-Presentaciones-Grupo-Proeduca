#!/usr/bin/env python3
# Creado por 686f6c61.dev (https://686f6c61.dev)
# /// script
# requires-python = ">=3.10"
# dependencies = ["resvg-py>=0.3"]
# ///
"""Convierte una figura SVG en PNG y comprueba que respeta la paleta de la institución.

Uso:
    uv run figura.py --institucion unipro|unir FIGURA.svg FIGURA.png [--ancho 2400]

Comprueba antes de convertir:
  - que el SVG tiene viewBox;
  - que todos los colores son de la paleta corporativa (error si no);
  - que no usa elementos que el conversor no admite (error);
  - que la fuente es Arial y el texto no queda demasiado pequeño (aviso).

Sale con código 1 si hay errores; en ese caso no genera el PNG.
Las reglas para dibujar las figuras están en references/figuras.md.
"""

import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

MARCAS = Path(__file__).resolve().parent.parent / "marcas"


def instituciones():
    return sorted(p.name for p in MARCAS.iterdir() if (p / "marca.json").is_file())


def paleta_de(institucion):
    """Paleta de figuras de la institución: {hexadecimal: nombre}."""
    import json
    datos = json.loads((MARCAS / institucion / "marca.json").read_text(encoding="utf-8"))
    return datos["paleta_figuras"]

SIN_COLOR = {"none", "currentcolor", "transparent", "inherit"}
ATRIBUTOS_COLOR = ("fill", "stroke", "stop-color", "flood-color", "color")
NO_ADMITIDOS = {"script", "foreignObject", "iframe", "video", "audio"}
ANCHO_PNG = 2400

_HEX = re.compile(r"^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")
_CSS_COLOR = re.compile(r"(fill|stroke|stop-color|flood-color|color)\s*:\s*([^;}\"]+)")
_CSS_FUENTE = re.compile(r"font-family\s*:\s*([^;}]+)")
_CSS_TAMANO = re.compile(r"font-size\s*:\s*([0-9.]+)")


def _local(etiqueta):
    return etiqueta.rsplit("}", 1)[-1]


def _normalizar(valor):
    """Devuelve el color como seis dígitos hexadecimales en mayúsculas, None si
    no pinta nada, o el texto original si no es un hexadecimal."""
    valor = valor.strip()
    if valor.lower() in SIN_COLOR or valor.lower().startswith("url("):
        return None
    m = _HEX.match(valor)
    if not m:
        return valor
    h = m.group(1)
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    return h.upper()


def analizar(texto_svg, paleta):
    """Devuelve (errores, avisos, (ancho, alto) del viewBox). `paleta` es el
    conjunto de colores admitidos, en hexadecimal de seis dígitos."""
    errores, avisos = [], []
    # Sin DOCTYPE ni entidades: evita la expansión de entidades y las
    # referencias a archivos externos al analizar el XML.
    if re.search(r"<!\s*(DOCTYPE|ENTITY)", texto_svg, re.IGNORECASE):
        return ["el SVG no puede llevar declaraciones DOCTYPE ni ENTITY"], [], None
    try:
        raiz = ET.fromstring(texto_svg)
    except ET.ParseError as e:
        return [f"el SVG no es XML válido: {e}"], [], None
    if _local(raiz.tag) != "svg":
        return ["el elemento raíz no es <svg>"], [], None

    medidas = None
    partes = raiz.get("viewBox", "").replace(",", " ").split()
    if len(partes) == 4:
        try:
            medidas = (float(partes[2]), float(partes[3]))
        except ValueError:
            pass
    if not medidas or medidas[0] <= 0 or medidas[1] <= 0:
        errores.append('falta un atributo viewBox válido en <svg> (por ejemplo viewBox="0 0 1200 600")')
        medidas = None

    colores, fuentes, tamanos = {}, set(), []

    def anotar_color(valor, donde):
        color = _normalizar(valor)
        if color is not None:
            colores.setdefault(color, donde)

    for el in raiz.iter():
        nombre = _local(el.tag)
        if nombre in NO_ADMITIDOS:
            errores.append(f"<{nombre}> no está admitido en las figuras")
        if nombre == "image":
            destino = el.get("href") or el.get("{http://www.w3.org/1999/xlink}href") or ""
            if not destino.startswith("data:"):
                errores.append("<image> con archivo externo: la figura debe ser autocontenida")
        for atributo in ATRIBUTOS_COLOR:
            if el.get(atributo) is not None:
                anotar_color(el.get(atributo), f'{atributo} de <{nombre}>')
        if el.get("font-family"):
            fuentes.add(el.get("font-family"))
        if el.get("font-size"):
            m = re.match(r"[0-9.]+", el.get("font-size"))
            if m:
                tamanos.append(float(m.group()))
        css = (el.get("style") or "") + (el.text or "" if nombre == "style" else "")
        for propiedad, valor in _CSS_COLOR.findall(css):
            anotar_color(valor, f"{propiedad} en estilos")
        fuentes.update(v.strip() for v in _CSS_FUENTE.findall(css))
        tamanos.extend(float(v) for v in _CSS_TAMANO.findall(css))

    for color, donde in sorted(colores.items()):
        if color not in paleta:
            if re.fullmatch(r"[0-9A-F]{6}", color):
                errores.append(f"color #{color} fuera de la paleta ({donde})")
            else:
                errores.append(f'color "{color}" no admitido ({donde}): usa el hexadecimal de la paleta')

    for fuente in sorted(fuentes):
        primera = fuente.split(",")[0].strip().strip("'\"").lower()
        if primera != "arial":
            avisos.append(f'fuente "{fuente}": las figuras deben usar Arial')
    if not fuentes and any(_local(e.tag) == "text" for e in raiz.iter()):
        avisos.append('hay texto sin font-family: añade font-family="Arial, Helvetica, sans-serif" en <svg>')
    if medidas and tamanos:
        minimo = medidas[0] / 80          # unos 10 pt con la figura a todo el ancho
        if min(tamanos) < minimo:
            avisos.append(
                f"hay texto con font-size {min(tamanos):g}; con este viewBox, por debajo de "
                f"{minimo:g} se leerá mal al proyectar"
            )
    return errores, avisos, medidas


def texto_minimo(texto_svg):
    """Devuelve (font-size más pequeño, ancho del viewBox), o None si no hay texto."""
    tamanos = [float(v) for v in re.findall(r'font-size\s*[=:]\s*["\']?\s*([0-9.]+)', texto_svg)]
    caja = re.search(r'viewBox\s*=\s*["\']\s*[-0-9.]+[\s,]+[-0-9.]+[\s,]+([0-9.]+)', texto_svg)
    if not tamanos or not caja:
        return None
    return min(tamanos), float(caja.group(1))


def rasterizar(texto_svg, destino, ancho=ANCHO_PNG):
    """Escribe el PNG. Usa resvg y, si no está, rsvg-convert."""
    try:
        import resvg_py
    except ImportError:
        resvg_py = None
    if resvg_py is not None:
        datos = resvg_py.svg_to_bytes(svg_string=texto_svg, width=int(ancho))
        Path(destino).write_bytes(bytes(datos))
        return "resvg"
    if shutil.which("rsvg-convert"):
        subprocess.run(
            ["rsvg-convert", "-w", str(int(ancho)), "-o", str(destino)],
            input=texto_svg.encode("utf-8"), check=True,
        )
        return "rsvg-convert"
    raise RuntimeError(
        "no hay conversor de SVG: ejecuta el script con «uv run» o instala el paquete resvg-py"
    )


def convertir(origen, destino, paleta, ancho=ANCHO_PNG):
    """Analiza y convierte. Devuelve (errores, avisos); sin errores, el PNG queda escrito."""
    texto = Path(origen).read_text(encoding="utf-8")
    errores, avisos, _ = analizar(texto, paleta)
    if not errores:
        Path(destino).parent.mkdir(parents=True, exist_ok=True)
        rasterizar(texto, destino, ancho)
    return errores, avisos


def main(argv):
    argv = list(argv)
    institucion = None
    if "--institucion" in argv:
        i = argv.index("--institucion")
        institucion = argv[i + 1].lower() if i + 1 < len(argv) else None
        del argv[i:i + 2]
    if institucion not in instituciones():
        print(f"[!] Indica la institución con --institucion ({', '.join(instituciones())}): "
              "cada una tiene su paleta.", file=sys.stderr)
        return 2
    paleta = paleta_de(institucion)
    args = [a for a in argv[1:] if not a.startswith("--")]
    ancho = ANCHO_PNG
    if "--ancho" in argv:
        try:
            ancho = int(argv[argv.index("--ancho") + 1])
            args.remove(str(ancho))
        except (IndexError, ValueError):
            print("[!] --ancho necesita un número de píxeles", file=sys.stderr)
            return 2
    if len(args) != 2:
        print(__doc__, file=sys.stderr)
        return 2
    origen, destino = Path(args[0]), Path(args[1])
    if not origen.is_file():
        print(f"[!] No existe {origen}", file=sys.stderr)
        return 1
    try:
        errores, avisos = convertir(origen, destino, paleta, ancho)
    except RuntimeError as e:
        print(f"[!] {e}", file=sys.stderr)
        return 3
    for aviso in avisos:
        print(f"[*] Aviso - {aviso}", file=sys.stderr)
    if errores:
        for error in errores:
            print(f"[!] Error - {error}", file=sys.stderr)
        print("[!] No se ha generado el PNG. Colores admitidos: "
              + ", ".join(f"#{c} ({n})" for c, n in paleta.items()), file=sys.stderr)
        return 1
    print(f"[OK] {destino} ({ancho} px de ancho, {len(avisos)} aviso(s))")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
