#!/usr/bin/env python3
# Creado por 686f6c61.dev (https://686f6c61.dev)
# /// script
# requires-python = ">=3.10"
# dependencies = ["python-pptx>=1.0", "resvg-py>=0.3"]
# ///
"""Genera una presentación de una institución de PROEDUCA (UNIPRO o UNIR) a partir
de una especificación JSON.

Uso:
    uv run generar.py ESPECIFICACION.json SALIDA.pptx
    python3 generar.py ESPECIFICACION.json SALIDA.pptx   (si python-pptx está instalado)

La especificación es un objeto con la clave "institucion" ("unipro" o "unir"),
que decide la plantilla, y la clave "diapositivas": una lista en la que
cada elemento tiene un "tipo" (portada, separador, texto, columnas, grafico,
cifras, tabla, cronologia, figura, referencias, cierre) y los campos de ese
tipo. Admite además "referencias" (bibliografía en formato APA). El formato completo
está en references/tipos-diapositiva.md.

Sale con código 1 y la lista de errores si la especificación no es válida.
"""

import copy
import json
import re
import sys
import tempfile
import unicodedata
from pathlib import Path

from lxml import etree
from pptx import Presentation
from pptx.chart.data import CategoryChartData, XyChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE, XL_LABEL_POSITION, XL_LEGEND_POSITION, XL_MARKER_STYLE
from pptx.enum.dml import MSO_THEME_COLOR
from pptx.util import Emu, Pt

sys.path.insert(0, str(Path(__file__).resolve().parent))
import figura as conversor  # noqa: E402  (analiza y convierte las figuras SVG)

MARCAS = Path(__file__).resolve().parent.parent / "marcas"


def instituciones():
    return sorted(p.name for p in MARCAS.iterdir() if (p / "marca.json").is_file())


def cargar_marca(institucion):
    """Datos de la institución: tipos de diapositiva, colores, paleta y rutas."""
    carpeta = MARCAS / institucion
    marca = json.loads((carpeta / "marca.json").read_text(encoding="utf-8"))
    marca["clave"] = institucion
    marca["plantilla"] = carpeta / "plantilla.pptx"
    marca["fragmentos"] = carpeta / "fragmentos.xml"
    return marca


NS = {
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
    "c": "http://schemas.openxmlformats.org/drawingml/2006/chart",
}

VERDE_AZULADO = RGBColor(0x00, 0x56, 0x6C)   # títulos y rótulos del original
CORAL = RGBColor(0xFF, 0x74, 0x75)           # segunda palabra del cierre


def q(tag):
    prefijo, nombre = tag.split(":")
    return "{%s}%s" % (NS[prefijo], nombre)


def sub(padre, tag, **atributos):
    el = etree.SubElement(padre, q(tag))
    for k, v in atributos.items():
        el.set(k, str(v))
    return el


_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")


def limpio(texto):
    """Texto sin caracteres de control que XML no admite."""
    return _CONTROL.sub("", str(texto)).strip()


# --------------------------------------------------------------------------
# Validación
# --------------------------------------------------------------------------

class Validador:
    def __init__(self):
        self.errores = []
        self.avisos = []
        self.donde = ""
        self.base = Path(".")
        self.marca = {}
        self.referencias = {}
        self.citadas = set()

    def error(self, mensaje):
        self.errores.append(f"{self.donde}: {mensaje}")

    def aviso(self, mensaje):
        self.avisos.append(f"{self.donde}: {mensaje}")

    def texto(self, d, clave, obligatorio=False, maximo=None):
        valor = d.get(clave)
        if valor is None or (isinstance(valor, str) and not valor.strip()):
            if obligatorio:
                self.error(f'falta el campo "{clave}"')
            return
        if not isinstance(valor, (str, int, float)):
            self.error(f'"{clave}" debe ser un texto')
            return
        if maximo and len(str(valor)) > maximo:
            self.aviso(f'"{clave}" tiene {len(str(valor))} caracteres; a partir de {maximo} puede desbordar su caja')

    def lista(self, d, clave, minimo, maximo, obligatorio=True):
        valor = d.get(clave)
        if valor is None:
            if obligatorio:
                self.error(f'falta la lista "{clave}"')
            return []
        if not isinstance(valor, list):
            self.error(f'"{clave}" debe ser una lista')
            return []
        if not minimo <= len(valor) <= maximo:
            self.error(f'"{clave}" admite entre {minimo} y {maximo} elementos y tiene {len(valor)}')
            return []
        return valor

    def textos(self, d, clave, maximo_elementos, maximo_caracteres=None, obligatorio=False):
        valores = self.lista(d, clave, 1 if obligatorio else 0, maximo_elementos, obligatorio)
        for i, v in enumerate(valores):
            if not isinstance(v, (str, int, float)):
                self.error(f'"{clave}"[{i + 1}] debe ser un texto')
            elif maximo_caracteres and len(str(v)) > maximo_caracteres:
                self.aviso(f'"{clave}"[{i + 1}] tiene {len(str(v))} caracteres; a partir de {maximo_caracteres} puede desbordar')
        return valores

    def icono(self, d, clave):
        valor = d.get(clave)
        iconos = self.marca.get("iconos", [])
        if valor is None:
            return
        if not iconos:
            self.aviso(f'"{clave}": la plantilla de {self.marca.get("nombre")} no tiene iconos; se ignora')
        elif valor not in iconos:
            self.error(f'"{clave}": icono desconocido {valor!r}; disponibles: {", ".join(iconos)}')

    def cabecera(self, d):
        self.texto(d, "antetitulo", maximo=45)
        self.texto(d, "titulo", obligatorio=True, maximo=45)


# Tipos que admiten una línea de fuentes al pie.
CON_FUENTES = ("texto", "columnas", "grafico", "cifras", "tabla", "cronologia", "figura", "cita")
FORMATOS_IMAGEN = (".svg", ".png", ".jpg", ".jpeg")


def validar_referencias(v, spec):
    referencias = spec.get("referencias")
    if referencias is None:
        return
    v.donde = "referencias"
    if not isinstance(referencias, dict):
        v.error('"referencias" debe ser un objeto cuyas claves identifican cada obra')
        return
    for clave, ref in referencias.items():
        v.donde = f"referencia «{clave}»"
        if not isinstance(ref, dict):
            v.error("debe ser un objeto con autores, anio y referencia")
            continue
        for campo in ("autores", "anio", "referencia"):
            if not str(ref.get(campo, "")).strip():
                v.error(f'falta el campo "{campo}"')
        texto = str(ref.get("referencia", ""))
        if texto and not re.search(r"\((\d{4}[a-z]?|s\. ?f\.)[^)]*\)", texto):
            v.aviso('la referencia no lleva el año entre paréntesis, como pide APA: «Apellido, N. (2024). Título…»')
        if texto.count("*") % 2:
            v.error('asteriscos de cursiva sin cerrar en "referencia"')
        v.referencias[clave] = ref


def validar_fuentes(v, d):
    tipo = d.get("tipo")
    if "fuentes" not in d and "nota_fuente" not in d:
        return
    if tipo not in CON_FUENTES:
        v.error(f'"fuentes" y "nota_fuente" no se admiten en el tipo {tipo}')
        return
    fuentes = d.get("fuentes", [])
    if not isinstance(fuentes, list):
        v.error('"fuentes" debe ser una lista de claves de "referencias"')
        return
    if len(fuentes) > 4:
        v.aviso(f'"fuentes" tiene {len(fuentes)} obras; con más de 4 la línea del pie no cabe')
    for clave in fuentes:
        if clave not in v.referencias:
            v.error(f'"fuentes": la clave «{clave}» no está en "referencias"')
        else:
            v.citadas.add(clave)
    v.texto(d, "nota_fuente", maximo=110)


def validar(spec, base=Path(".")):
    v = Validador()
    v.base = Path(base)
    v.donde = "especificación"
    if not isinstance(spec, dict) or not isinstance(spec.get("diapositivas"), list) or not spec["diapositivas"]:
        v.error('debe ser un objeto con una lista "diapositivas" no vacía')
        return v
    institucion = str(spec.get("institucion", "")).strip().lower()
    if institucion not in instituciones():
        v.error('falta "institucion" o no es válida: debe ser una de ' + ", ".join(instituciones())
                + ". Si el usuario no ha dicho para qué institución es la presentación, pregúntaselo")
        return v
    v.marca = cargar_marca(institucion)
    validar_referencias(v, spec)
    for n, d in enumerate(spec["diapositivas"], 1):
        v.donde = f"diapositiva {n}"
        if not isinstance(d, dict):
            v.error("debe ser un objeto")
            continue
        tipo = d.get("tipo")
        v.donde = f"diapositiva {n} ({tipo})"
        comprobar = VALIDADORES.get(tipo)
        if comprobar is None or tipo not in v.marca["tipos"]:
            v.error(f'tipo desconocido o no disponible en la plantilla de {v.marca["nombre"]}; '
                    f'tipos válidos: {", ".join(v.marca["tipos"])}')
            continue
        comprobar(v, d)
        validar_fuentes(v, d)
        if "notas" in d and not isinstance(d["notas"], str):
            v.error('"notas" debe ser un texto')
    v.donde = "referencias"
    sin_citar = [c for c in v.referencias if c not in v.citadas]
    if sin_citar:
        v.aviso("obras que ninguna diapositiva cita en \"fuentes\" y que no saldrán en la lista final: "
                + ", ".join(sin_citar))
    if sum(1 for d in spec["diapositivas"] if isinstance(d, dict) and d.get("tipo") == "referencias") > 1:
        v.error('solo puede haber una diapositiva de tipo "referencias"')
    return v


def v_portada(v, d):
    v.texto(d, "subtitulo", maximo=30)
    if v.marca.get("clave") == "unipro" and d.get("subtitulo"):
        v.aviso('la portada de UNIPRO no tiene "subtitulo"; se ignora')
    v.texto(d, "titulo", obligatorio=True, maximo=45)
    v.texto(d, "autor", maximo=60)
    v.texto(d, "pie", maximo=110)


def v_separador(v, d):
    v.texto(d, "titulo", obligatorio=True, maximo=40)
    v.texto(d, "subtitulo", maximo=80)
    v.texto(d, "numero", maximo=2)
    colores = v.marca["separadores"]
    if d.get("color", colores[0]) not in colores:
        v.error(f'"color" debe ser uno de: {", ".join(colores)} (por defecto, {colores[0]})')


def v_texto(v, d):
    v.cabecera(d)
    v.texto(d, "entradilla", maximo=140)
    v.texto(d, "nota", maximo=120)
    if d.get("nota") and not d.get("entradilla"):
        v.error('"nota" solo se admite junto a "entradilla"')
    parrafos = v.textos(d, "cuerpo", 6, 700)
    puntos = v.textos(d, "lista", 10, 220)
    if not d.get("entradilla") and not parrafos and not puntos:
        v.error('necesita al menos "entradilla", "cuerpo" o "lista"')
    total = sum(len(str(t)) for t in parrafos + puntos)
    if total > 1500:
        v.aviso(f"el cuerpo suma {total} caracteres; por encima de 1500 no cabe en la diapositiva")


def v_columnas(v, d):
    v.cabecera(d)
    columnas = v.lista(d, "columnas", 2, 4)
    ancho = {2: 34, 3: 22, 4: 16}.get(len(columnas), 16)
    for i, col in enumerate(columnas, 1):
        if not isinstance(col, dict):
            v.error(f"columna {i}: debe ser un objeto")
            continue
        base = v.donde
        v.donde = f"{base}, columna {i}"
        v.texto(col, "rotulo", obligatorio=True, maximo=ancho)
        v.icono(col, "icono")
        v.textos(col, "puntos", 6, 110, obligatorio=True)
        v.donde = base


def _numero(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool)


def v_ejes(v, d):
    v.texto(d, "eje_x", maximo=40)
    v.texto(d, "eje_y", maximo=40)
    decimales = d.get("decimales")
    if decimales is not None and (not isinstance(decimales, int) or isinstance(decimales, bool) or not 0 <= decimales <= 4):
        v.error('"decimales" debe ser un entero entre 0 y 4')
    for clave in ("eje_minimo", "eje_maximo"):
        if d.get(clave) is not None and not _numero(d[clave]):
            v.error(f'"{clave}" debe ser un número')


def v_dispersion(v, d):
    if d.get("categorias") or d.get("descripciones"):
        v.error('un gráfico de dispersión no lleva "categorias" ni "descripciones"')
    series = v.lista(d, "series", 1, 4)
    for i, s in enumerate(series, 1):
        puntos = s.get("puntos") if isinstance(s, dict) else None
        if not isinstance(puntos, list) or len(puntos) < 2:
            v.error(f'serie {i}: necesita "puntos", una lista de al menos dos pares [x, y]')
            continue
        if len(puntos) > 500:
            v.error(f"serie {i}: tiene {len(puntos)} puntos; el máximo es 500 (toma una muestra)")
        if not all(isinstance(p, list) and len(p) == 2 and _numero(p[0]) and _numero(p[1]) for p in puntos):
            v.error(f"serie {i}: cada punto debe ser un par [x, y] de números")
        if len(series) > 1 and not str(s.get("nombre", "")).strip():
            v.error(f'serie {i}: falta "nombre" (obligatorio cuando hay varias series)')
    if not d.get("eje_x") or not d.get("eje_y"):
        v.aviso('un gráfico de dispersión debe llevar "eje_x" y "eje_y" con la magnitud y su unidad')
    if not d.get("fuentes") and not d.get("nota_fuente"):
        v.aviso("indica de dónde salen los puntos: un gráfico de dispersión solo se dibuja con datos reales")


def v_grafico(v, d):
    v.cabecera(d)
    v_ejes(v, d)
    if d.get("grafico", "columnas") not in ("columnas", "lineas", "dispersion"):
        v.error('"grafico" debe ser "columnas", "lineas" o "dispersion"')
    if d.get("grafico") == "dispersion":
        v_dispersion(v, d)
        return
    categorias = v.textos(d, "categorias", 6, 18, obligatorio=True)
    series = v.lista(d, "series", 1, 4)
    for i, s in enumerate(series, 1):
        if not isinstance(s, dict) or not isinstance(s.get("valores"), list):
            v.error(f'serie {i}: debe ser un objeto con una lista "valores"')
            continue
        if len(s["valores"]) != len(categorias):
            v.error(f'serie {i}: tiene {len(s["valores"])} valores y hay {len(categorias)} categorías')
        if not all(isinstance(x, (int, float)) and not isinstance(x, bool) for x in s["valores"]):
            v.error(f"serie {i}: todos los valores deben ser numéricos")
        if len(series) > 1 and not str(s.get("nombre", "")).strip():
            v.error(f'serie {i}: falta "nombre" (obligatorio cuando hay varias series)')
    descripciones = v.textos(d, "descripciones", 6, 90)
    if descripciones and len(descripciones) != len(categorias):
        v.error(f'"descripciones" tiene {len(descripciones)} elementos y hay {len(categorias)} categorías')


_CIENTIFICA = re.compile(r"\d[eE][-+]?\d")


def v_numero_escrito(v, texto, donde):
    """Avisa de las formas de escribir números que no se usan en español."""
    texto = str(texto)
    if _CIENTIFICA.search(texto):
        v.aviso(f"{donde}: «{texto}» está en notación científica; escribe «< 0,001» o «2,3 × 10⁻⁸»")
    elif re.fullmatch(r"[-−+]?\d+\.\d{1,2}\s*%?", texto.strip()):
        v.aviso(f"{donde}: «{texto}» lleva punto decimal; en español se usa la coma")
    if re.match(r"-\d", texto.strip()):
        v.aviso(f"{donde}: «{texto}» usa un guion como signo menos; el signo correcto es «−»")


def v_cifras(v, d):
    v.texto(d, "titulo", maximo=45)
    v.texto(d, "antetitulo", maximo=60)
    if v.marca.get("clave") == "unipro" and (d.get("titulo") or d.get("antetitulo")):
        v.aviso("en la plantilla de UNIPRO la diapositiva de cifras no lleva título; se ignora")
    for i, c in enumerate(v.lista(d, "cifras", 2, 4), 1):
        if not isinstance(c, dict):
            v.error(f"cifra {i}: debe ser un objeto")
            continue
        base = v.donde
        v.donde = f"{base}, cifra {i}"
        v.texto(c, "valor", obligatorio=True, maximo=7)
        if c.get("valor") is not None:
            v_numero_escrito(v, c["valor"], "valor")
        v.texto(c, "texto", obligatorio=True, maximo=34)
        v.texto(c, "detalle", maximo=34)
        v.donde = base


def v_tabla(v, d):
    v.cabecera(d)
    cabecera = v.textos(d, "cabecera", 6, 16, obligatorio=True)
    if cabecera and len(cabecera) < 2:
        v.error('"cabecera" necesita al menos dos columnas')
    filas = v.lista(d, "filas", 1, 8)
    for i, fila in enumerate(filas, 1):
        if not isinstance(fila, list) or len(fila) != len(cabecera):
            v.error(f"fila {i}: debe ser una lista de {len(cabecera)} celdas")
        elif any(len(str(c)) > 22 for c in fila):
            v.aviso(f"fila {i}: alguna celda supera los 22 caracteres y puede desbordar")
        if isinstance(fila, list):
            for celda in fila[1:]:
                v_numero_escrito(v, celda, f"fila {i}")
    total = d.get("total")
    if total is not None and (not isinstance(total, list) or len(total) != len(cabecera)):
        v.error(f'"total" debe ser una lista de {len(cabecera)} celdas')
    if len(filas) + (2 if total else 1) > 9:
        v.error("la tabla admite como máximo 9 filas contando cabecera y total")


def v_cronologia(v, d):
    v.cabecera(d)
    hitos = v.lista(d, "hitos", 3, 6)
    ancho = {3: 22, 4: 16, 5: 12, 6: 10}.get(len(hitos), 10)
    for i, h in enumerate(hitos, 1):
        if not isinstance(h, dict):
            v.error(f"hito {i}: debe ser un objeto")
            continue
        base = v.donde
        v.donde = f"{base}, hito {i}"
        v.texto(h, "marca", maximo=8)
        v.texto(h, "titulo", obligatorio=True, maximo=ancho)
        v.texto(h, "texto", maximo=ancho * 8)
        v.donde = base
    v.icono(d, "icono_inicio")
    v.icono(d, "icono_fin")


def v_figura(v, d):
    v.cabecera(d)
    imagen = d.get("imagen")
    if not isinstance(imagen, str) or not imagen.strip():
        v.error('falta el campo "imagen" (ruta de un archivo SVG, PNG o JPG)')
    else:
        ruta = v.base / imagen
        if ruta.suffix.lower() not in FORMATOS_IMAGEN:
            v.error(f'"imagen": formato no admitido; usa {", ".join(FORMATOS_IMAGEN)}')
        elif not ruta.is_file():
            v.error(f'"imagen": no existe el archivo {ruta}')
        elif ruta.suffix.lower() == ".svg":
            errores, avisos, _ = conversor.analizar(ruta.read_text(encoding="utf-8"), v.marca["paleta_figuras"])
            if errores:
                errores.append("colores admitidos en " + v.marca["nombre"] + ": "
                               + ", ".join(f"#{c} ({n})" for c, n in v.marca["paleta_figuras"].items()))
            for e in errores:
                v.error(f"figura {ruta.name}: {e}")
            for a in avisos:
                v.aviso(f"figura {ruta.name}: {a}")
    v.texto(d, "pie", maximo=110)
    v.texto(d, "descripcion", maximo=300)
    if not d.get("descripcion"):
        v.aviso('falta "descripcion": el texto alternativo que leen los lectores de pantalla')
    v.textos(d, "puntos", 6, 110)


def v_referencias(v, d):
    v.texto(d, "titulo", maximo=45)
    v.texto(d, "antetitulo", maximo=45)


def v_agenda(v, d):
    v.texto(d, "titulo", maximo=45)
    v.texto(d, "antetitulo", maximo=60)
    v.textos(d, "puntos", 8, 70, obligatorio=True)


def v_cita(v, d):
    v.texto(d, "texto", obligatorio=True, maximo=190)
    v.texto(d, "autor", maximo=70)


def v_cierre(v, d):
    v.texto(d, "texto", maximo=16)


VALIDADORES = {
    "portada": v_portada, "separador": v_separador, "texto": v_texto,
    "columnas": v_columnas, "grafico": v_grafico, "cifras": v_cifras,
    "tabla": v_tabla, "cronologia": v_cronologia, "figura": v_figura,
    "referencias": v_referencias, "cierre": v_cierre,
    "agenda": v_agenda, "cita": v_cita,
}


# --------------------------------------------------------------------------
# Fragmentos: formas modelo copiadas de la plantilla original
# --------------------------------------------------------------------------

class Fragmentos:
    def __init__(self, ruta):
        raiz = etree.parse(str(ruta)).getroot()
        self._modelos = {f.get("nombre"): f[0] for f in raiz}

    def clonar(self, nombre):
        return copy.deepcopy(self._modelos[nombre])


def _xfrm(el):
    if etree.QName(el).localname == "graphicFrame":
        return el.find(q("p:xfrm"))
    return el.find(q("p:spPr")).find(q("a:xfrm"))


def medidas(el):
    ext = _xfrm(el).find(q("a:ext"))
    return int(ext.get("cx")), int(ext.get("cy"))


def colocar(el, x=None, y=None, cx=None, cy=None):
    xfrm = _xfrm(el)
    off, ext = xfrm.find(q("a:off")), xfrm.find(q("a:ext"))
    for nodo, clave, valor in ((off, "x", x), (off, "y", y), (ext, "cx", cx), (ext, "cy", cy)):
        if valor is not None:
            nodo.set(clave, str(round(valor)))
    return el


def escribir(el, textos):
    """Rellena los párrafos de una forma modelo. Cada texto usa el párrafo
    modelo de su posición (o el último disponible) y conserva su formato."""
    cuerpo = el.find(q("p:txBody"))
    modelos = cuerpo.findall(q("a:p"))
    for m in modelos:
        cuerpo.remove(m)
    for i, texto in enumerate(textos):
        p = copy.deepcopy(modelos[min(i, len(modelos) - 1)])
        p.find(q("a:r")).find(q("a:t")).text = limpio(texto)
        cuerpo.append(p)
    return el


def colorear(el, esquema):
    """Cambia el relleno sólido de una forma por un color del tema."""
    relleno = el.find(q("p:spPr")).find(q("a:solidFill"))
    for c in list(relleno):
        relleno.remove(c)
    sub(relleno, "a:schemeClr", val=esquema)
    return el


def anadir(diapositiva, el, nombre=None):
    """Añade la forma a la diapositiva con un identificador libre. `nombre` es
    el que verá quien edite el archivo (y el que usa la auditoría)."""
    arbol = diapositiva.shapes._spTree
    ids = [int(x.get("id")) for x in arbol.iter(q("p:cNvPr")) if x.get("id", "").isdigit()]
    nv = el[0].find(q("p:cNvPr"))
    nv.set("id", str(max(ids, default=1) + 1))
    if nombre:
        nv.set("name", nombre)
    arbol.append(el)
    return el


def espaciar_puntos(el, puntos=1600):
    """Añade espacio tras cada párrafo de una lista (el original separa los
    puntos con una línea en blanco)."""
    for p in el.find(q("p:txBody")).findall(q("a:p")):
        ppr = p.find(q("a:pPr"))
        if ppr is None:
            ppr = etree.Element(q("a:pPr"))
            p.insert(0, ppr)
        espacio = etree.Element(q("a:spcAft"))
        sub(espacio, "a:spcPts", val=puntos)
        ppr.insert(0, espacio)


# --------------------------------------------------------------------------
# Marcadores de posición
# --------------------------------------------------------------------------

def marcador(diapositiva, idx):
    for ph in diapositiva.placeholders:
        if ph.placeholder_format.idx == idx:
            return ph
    raise LookupError(f"El diseño no tiene el marcador {idx}")


def rellenar(diapositiva, idx, texto):
    """Escribe el texto en el marcador, o lo elimina si no hay texto."""
    ph = marcador(diapositiva, idx)
    if texto is None or not limpio(texto):
        ph._element.getparent().remove(ph._element)
        return None
    # "\n" dentro de un título es un salto de línea, no un párrafo nuevo.
    ph.text_frame.text = limpio(texto).replace("\n", "\v")
    return ph


def titulo_doble(diapositiva, d):
    """Título de dos líneas: antetítulo en el azul del tema y título debajo."""
    parrafo = marcador(diapositiva, 0).text_frame.paragraphs[0]
    if d.get("antetitulo"):
        tramo = parrafo.add_run()
        tramo.text = limpio(d["antetitulo"])
        tramo.font.color.theme_color = MSO_THEME_COLOR.ACCENT_1
        parrafo.add_line_break()
    parrafo.add_run().text = limpio(d["titulo"])


def numero_pagina(diapositiva, n):
    cero = '<a:r><a:rPr lang="es-ES"/><a:t>0</a:t></a:r>' if n < 10 else ""
    xml = (
        f'<p:sp xmlns:p="{NS["p"]}" xmlns:a="{NS["a"]}">'
        '<p:nvSpPr><p:cNvPr id="0" name="Número de página"/>'
        '<p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr>'
        '<p:nvPr><p:ph type="sldNum" sz="quarter" idx="14"/></p:nvPr></p:nvSpPr>'
        "<p:spPr/><p:txBody><a:bodyPr/><a:lstStyle/>"
        '<a:p><a:r><a:rPr lang="es-ES"/><a:t>pág.</a:t></a:r></a:p>'
        f"<a:p>{cero}"
        '<a:fld id="{B9E8122E-6AE8-4447-899B-CEE3D632C219}" type="slidenum">'
        f'<a:rPr lang="es-ES"/><a:t>{n}</a:t></a:fld></a:p>'
        "</p:txBody></p:sp>"
    )
    anadir(diapositiva, etree.fromstring(xml))


def orden_apa(texto):
    """Clave de ordenación alfabética: sin cursivas, sin tildes y sin mayúsculas."""
    plano = unicodedata.normalize("NFD", texto.replace("*", ""))
    return "".join(c for c in plano if unicodedata.category(c) != "Mn").casefold()


def tramos_cursiva(parrafo, texto):
    """Escribe el texto en el párrafo; lo que va entre asteriscos, en cursiva."""
    for i, trozo in enumerate(limpio(texto).split("*")):
        if trozo:
            tramo = parrafo.add_run()
            tramo.text = trozo
            if i % 2:
                tramo.font.italic = True


# --------------------------------------------------------------------------
# Constructores por tipo de diapositiva (medidas en EMU, tomadas del original)
# --------------------------------------------------------------------------

class Generador:
    """Generador de UNIPRO. Las medidas de cada tipo de diapositiva son las de su
    plantilla; GeneradorUnir redefine los mismos métodos con las de la suya."""

    def __init__(self, marca, base=Path(".")):
        self.marca = marca
        self.colores_serie = marca["colores_serie"]
        self.prs = Presentation(str(marca["plantilla"]))
        self.frag = Fragmentos(marca["fragmentos"])
        self.disenos = {d.name: d for d in self.prs.slide_layouts}
        self.base = Path(base)      # las rutas de imagen son relativas a la especificación
        self.obras = {}             # referencias APA por clave
        self.citadas = []           # claves citadas, en orden de aparición
        self.avisos = []
        self.tmp = None

    def nueva(self, diseno):
        return self.prs.slides.add_slide(self.disenos[diseno])

    def con_cabecera(self, d, diseno="Contenido"):
        diapositiva = self.nueva(diseno)
        titulo_doble(diapositiva, d)
        return diapositiva

    def portada(self, d):
        s = self.nueva("Portada")
        rellenar(s, 0, d["titulo"])
        rellenar(s, 1, d.get("autor"))
        rellenar(s, 10, d.get("pie"))
        return s

    def separador(self, d):
        s = self.nueva("Separador azul" if d.get("color") == "azul" else "Separador marino")
        if d.get("numero") is not None:
            d = dict(d, numero=str(d["numero"]).zfill(2))
        rellenar(s, 0, d["titulo"])
        rellenar(s, 1, d.get("subtitulo"))
        rellenar(s, 10, d.get("numero"))
        return s

    def texto(self, d):
        s = self.con_cabecera(d, "Texto")
        entradilla, cuerpo = marcador(s, 12), marcador(s, 13)
        arriba = entradilla.top
        if d.get("entradilla"):
            parrafo = entradilla.text_frame.paragraphs[0]
            parrafo.add_run().text = limpio(d["entradilla"])
            if d.get("nota"):
                nota = parrafo.add_run()
                nota.text = " – " + limpio(d["nota"])
                nota.font.size = Emu(1597 * 127)          # 15,97 pt, como el original
                nota.font.color.theme_color = MSO_THEME_COLOR.ACCENT_2
        else:
            entradilla._element.getparent().remove(entradilla._element)

        parrafos = [limpio(t) for t in d.get("cuerpo", [])]
        puntos = [limpio(t) for t in d.get("lista", [])]
        if not parrafos and not puntos:
            cuerpo._element.getparent().remove(cuerpo._element)
            return s
        if not d.get("entradilla"):
            # Sin entradilla el cuerpo sube a ocupar su sitio.
            izquierda, ancho, alto = cuerpo.left, cuerpo.width, cuerpo.height + (cuerpo.top - arriba)
            cuerpo.left, cuerpo.top, cuerpo.width, cuerpo.height = izquierda, arriba, ancho, alto
        marco = cuerpo.text_frame
        primero = True
        for t in parrafos:
            p = marco.paragraphs[0] if primero else marco.add_paragraph()
            p.add_run().text = t
            primero = False
        modelo = self.frag.clonar("col_lista_a").find(q("p:txBody")).find(q("a:p")).find(q("a:pPr"))
        for t in puntos:
            p = marco.paragraphs[0] if primero else marco.add_paragraph()
            p.add_run().text = t
            ppr = p._p.get_or_add_pPr()
            ppr.set("marL", "341313")
            ppr.set("indent", "-341313")
            espacio = etree.SubElement(ppr, q("a:spcAft"))
            sub(espacio, "a:spcPts", val=600)
            for vineta in modelo:
                ppr.append(copy.deepcopy(vineta))
            primero = False
        return s

    def columnas(self, d):
        s = self.con_cabecera(d)
        columnas = d["columnas"]
        izquierda, derecha, hueco = 911559, 11256630, 219291
        paso = (derecha - izquierda + hueco) / len(columnas)
        ancho = paso - hueco
        for i, col in enumerate(columnas):
            x = izquierda + i * paso
            estilo = "a" if i % 2 == 0 else "b"
            if col.get("icono"):
                icono = colorear(self.frag.clonar("icono_" + col["icono"]), "accent1" if estilo == "a" else "accent5")
                anadir(s, colocar(icono, x, 2053134), f"Icono columna {i + 1}")
            rotulo = escribir(self.frag.clonar("col_rotulo_" + estilo), [col["rotulo"]])
            anadir(s, colocar(rotulo, x, 2569648, ancho), f"Rótulo columna {i + 1}")
            lista = escribir(self.frag.clonar("col_lista_" + estilo), col["puntos"])
            espaciar_puntos(lista)
            anadir(s, colocar(lista, x, 3254109, ancho), f"Lista columna {i + 1}")
        return s

    def _formato(self, d):
        """Formato numérico de etiquetas y ejes: mismo número de decimales en todos."""
        decimales = d.get("decimales")
        if decimales is None:
            return None
        return "#,##0" + ("." + "0" * decimales if decimales else "")

    def _titulo_eje(self, eje, texto):
        eje.has_title = True
        marco = eje.axis_title.text_frame
        marco.text = limpio(texto)
        fuente = marco.paragraphs[0].runs[0].font
        fuente.size = Emu(1597 * 127)
        fuente.bold = False
        fuente.color.theme_color = MSO_THEME_COLOR.TEXT_2

    def _idioma(self, grafico):
        """Marca el gráfico como español para que los decimales salgan con coma."""
        espacio = grafico._chartSpace
        idioma = espacio.find(q("c:lang"))
        if idioma is None:
            idioma = etree.Element(q("c:lang"))
            referencia = espacio.find(q("c:date1904"))
            if referencia is not None:
                referencia.addnext(idioma)
            else:
                espacio.insert(0, idioma)
        idioma.set("val", "es-ES")

    def dispersion(self, s, d):
        datos = XyChartData()
        for serie in d["series"]:
            puntos = datos.add_series(limpio(serie.get("nombre", "")))
            for x, y in serie["puntos"]:
                puntos.add_data_point(x, y)
        marco = s.shapes.add_chart(XL_CHART_TYPE.XY_SCATTER, Emu(849239), Emu(1686609), Emu(10469711), Emu(4150000), datos)
        grafico = marco.chart
        grafico.has_title = False
        self._idioma(grafico)
        formato = self._formato(d)
        for i, (serie, definicion) in enumerate(zip(grafico.plots[0].series, d["series"])):
            color = RGBColor.from_string(self.colores_serie[i % len(self.colores_serie)])
            if definicion.get("linea"):          # recta o curva ajustada: línea sin puntos
                serie.format.line.color.rgb = color
                serie.format.line.width = Pt(2.25)
                serie.marker.style = XL_MARKER_STYLE.NONE
            else:                                # observaciones: puntos sin línea
                serie.format.line.fill.background()
                serie.marker.style = XL_MARKER_STYLE.CIRCLE
                serie.marker.size = 7
                serie.marker.format.fill.solid()
                serie.marker.format.fill.fore_color.rgb = color
                serie.marker.format.line.fill.background()
            serie.smooth = False
        for eje, clave in ((grafico.category_axis, "eje_x"), (grafico.value_axis, "eje_y")):
            eje.format.line.color.rgb = RGBColor(0xA5, 0xA5, 0xA5)
            eje.tick_labels.font.size = Emu(1597 * 127)
            eje.tick_labels.font.color.theme_color = MSO_THEME_COLOR.TEXT_2
            if formato:
                eje.tick_labels.number_format = formato
                eje.tick_labels.number_format_is_linked = False
            if d.get(clave):
                self._titulo_eje(eje, d[clave])
        grafico.category_axis.has_major_gridlines = False
        grafico.value_axis.has_major_gridlines = True
        grafico.value_axis.major_gridlines.format.line.color.rgb = RGBColor(0xF4, 0xB1, 0x83)
        grafico.value_axis.major_gridlines.format.line.width = Emu(9507)
        if d.get("eje_minimo") is not None:
            grafico.value_axis.minimum_scale = d["eje_minimo"]
        if d.get("eje_maximo") is not None:
            grafico.value_axis.maximum_scale = d["eje_maximo"]
        grafico.has_legend = len(d["series"]) > 1
        if grafico.has_legend:
            grafico.legend.position = XL_LEGEND_POSITION.TOP
            grafico.legend.include_in_layout = False
            grafico.legend.font.size = Emu(1597 * 127)
            grafico.legend.font.color.theme_color = MSO_THEME_COLOR.TEXT_2
        return s

    def grafico(self, d):
        s = self.con_cabecera(d)
        if d.get("grafico") == "dispersion":
            return self.dispersion(s, d)
        categorias = [limpio(c) for c in d["categorias"]]
        series = d["series"]
        lineas = d.get("grafico") == "lineas"
        datos = CategoryChartData()
        datos.categories = categorias
        for serie in series:
            datos.add_series(limpio(serie.get("nombre", "")), serie["valores"])
        x, y, cx, cy = 849239, 1686609, 10469711, 3130773
        tipo = XL_CHART_TYPE.LINE_MARKERS if lineas else XL_CHART_TYPE.COLUMN_CLUSTERED
        grafico = s.shapes.add_chart(tipo, Emu(x), Emu(y), Emu(cx), Emu(cy), datos).chart

        grafico.has_title = False
        trazado = grafico.plots[0]
        if not lineas:
            trazado.gap_width = 150
            trazado.overlap = -30
        trazado.has_data_labels = True
        etiquetas = trazado.data_labels
        etiquetas.position = XL_LABEL_POSITION.ABOVE if lineas else XL_LABEL_POSITION.OUTSIDE_END
        etiquetas.font.size = Emu(1996 * 127)
        etiquetas.font.bold = True
        etiquetas.font.color.rgb = VERDE_AZULADO
        for i, serie in enumerate(trazado.series):
            color = RGBColor.from_string(self.colores_serie[i % len(self.colores_serie)])
            if lineas:
                serie.format.line.color.rgb = color
                serie.format.line.width = Pt(2.25)
                serie.smooth = False
                serie.marker.format.fill.solid()
                serie.marker.format.fill.fore_color.rgb = color
                serie.marker.format.line.color.rgb = color
            else:
                serie.format.fill.solid()
                serie.format.fill.fore_color.rgb = color

        grafico.category_axis.visible = False      # las categorías van como rótulos debajo
        eje = grafico.value_axis
        eje.has_major_gridlines = True
        eje.major_gridlines.format.line.color.rgb = RGBColor(0xF4, 0xB1, 0x83)   # accent2 aclarado
        eje.major_gridlines.format.line.width = Emu(9507)
        eje.format.line.fill.background()
        eje.tick_labels.font.size = Emu(2395 * 127)
        eje.tick_labels.font.bold = True
        eje.tick_labels.font.color.theme_color = MSO_THEME_COLOR.ACCENT_2
        # Las columnas se comparan por su altura: el eje empieza en cero salvo
        # que se pida otra cosa. Un eje recortado exagera las diferencias.
        if d.get("eje_minimo") is not None:
            eje.minimum_scale = d["eje_minimo"]
        elif not lineas and all(v >= 0 for serie in series for v in serie["valores"]):
            eje.minimum_scale = 0
        if d.get("eje_maximo") is not None:
            eje.maximum_scale = d["eje_maximo"]
        formato = self._formato(d)
        if formato:
            etiquetas.number_format = formato
            etiquetas.number_format_is_linked = False
            eje.tick_labels.number_format = formato
            eje.tick_labels.number_format_is_linked = False
        if d.get("eje_y"):
            self._titulo_eje(eje, d["eje_y"])
        self._idioma(grafico)

        grafico.has_legend = len(series) > 1
        if grafico.has_legend:
            grafico.legend.position = XL_LEGEND_POSITION.TOP
            grafico.legend.include_in_layout = False
            grafico.legend.font.size = Emu(1597 * 127)
            grafico.legend.font.bold = True
            grafico.legend.font.color.theme_color = MSO_THEME_COLOR.ACCENT_2

        # Área de trazado con las proporciones del gráfico original.
        fx, fy, fw, fh = 0.0372827, 0.1648339, 0.9627173, 0.7021869
        # El original reserva sitio para etiquetas de eje de una cifra. Con
        # números más largos o con título de eje, el trazado se desplaza a la
        # derecha lo necesario para que no se monten.
        mayor = max(abs(v) for serie in series for v in serie["valores"])
        decimales = d.get("decimales")
        muestra = f"{mayor:,.{decimales}f}" if decimales is not None else f"{mayor:g}"
        necesario = len(muestra) * 0.6 * 23.95 + 12 + (30 if d.get("eje_y") else 0)     # en puntos
        fx = max(fx, necesario * 12700 / cx)
        fw = 1 - fx
        area = grafico._chartSpace.find(".//" + q("c:plotArea"))
        anterior = area.find(q("c:layout"))
        if anterior is not None:
            area.remove(anterior)
        disposicion = etree.Element(q("c:layout"))
        manual = sub(disposicion, "c:manualLayout")
        sub(manual, "c:layoutTarget", val="inner")
        sub(manual, "c:xMode", val="edge")
        sub(manual, "c:yMode", val="edge")
        for clave, valor in (("x", fx), ("y", fy), ("w", fw), ("h", fh)):
            sub(manual, "c:" + clave, val=valor)
        area.insert(0, disposicion)

        # Rótulo (y descripción opcional) centrado bajo cada categoría.
        descripciones = d.get("descripciones") or []
        tramo = cx * fw / len(categorias)
        modelo_rotulo, modelo_texto = self.frag.clonar("graf_rotulo"), self.frag.clonar("graf_texto")
        y_rotulo = int(_xfrm(modelo_rotulo).find(q("a:off")).get("y"))
        y_texto = int(_xfrm(modelo_texto).find(q("a:off")).get("y"))
        ancho = min(tramo - 150000, 2600000)
        for i, categoria in enumerate(categorias):
            centro = x + cx * fx + tramo * (i + 0.5)
            rotulo = escribir(self.frag.clonar("graf_rotulo"), [categoria])
            anadir(s, colocar(rotulo, centro - ancho / 2, y_rotulo, ancho), f"Rótulo categoría {i + 1}")
            if descripciones:
                texto = escribir(self.frag.clonar("graf_texto"), [descripciones[i]])
                anadir(s, colocar(texto, centro - ancho / 2, y_texto, ancho), f"Descripción categoría {i + 1}")
        return s

    def cifras(self, d):
        s = self.nueva("Solo logotipo")
        cifras = d["cifras"]
        alto_linea = 1166118
        paso = 1643550 if len(cifras) <= 3 else 1400000
        centro = 3277346                      # centro vertical del bloque original
        y0 = centro - ((len(cifras) - 1) * paso + alto_linea) / 2
        for i, cifra in enumerate(cifras):
            y = y0 + i * paso
            valor = escribir(self.frag.clonar("cifra_valor"), [cifra["valor"]])
            anadir(s, colocar(valor, y=y + 61264), f"Cifra {i + 1}")
            anadir(s, colocar(self.frag.clonar("cifra_linea"), y=y), f"Línea cifra {i + 1}")
            lineas = [cifra["texto"]] + ([cifra["detalle"]] if cifra.get("detalle") else [])
            texto = escribir(self.frag.clonar("cifra_texto"), lineas)
            anadir(s, colocar(texto, y=y + 102458), f"Texto cifra {i + 1}")
        return s

    def tabla(self, d):
        s = self.con_cabecera(d)
        marco = self.frag.clonar("tabla")
        tabla = marco.find(".//" + q("a:tbl"))
        modelos = tabla.findall(q("a:tr"))
        m_cabecera, m_impar, m_par, m_total = modelos[0], modelos[1], modelos[2], modelos[-1]
        for fila in modelos:
            tabla.remove(fila)

        cabecera = d["cabecera"]
        filas = [(m_cabecera, cabecera)]
        filas += [(m_impar if i % 2 == 0 else m_par, fila) for i, fila in enumerate(d["filas"])]
        if d.get("total"):
            filas.append((m_total, d["total"]))

        ancho_total, alto_total = medidas(marco)
        columnas = len(cabecera)
        rejilla = tabla.find(q("a:tblGrid"))
        for c in list(rejilla):
            rejilla.remove(c)
        ancho = ancho_total // columnas
        for _ in range(columnas):
            sub(rejilla, "a:gridCol", w=ancho)
        alto = min(526021, alto_total // len(filas))

        for modelo, celdas in filas:
            fila = copy.deepcopy(modelo)
            fila.set("h", str(alto))
            originales = fila.findall(q("a:tc"))
            primera, resto = originales[0], originales[1]
            for c in originales:
                fila.remove(c)
            for i, valor in enumerate(celdas):
                celda = copy.deepcopy(primera if i == 0 else resto)
                parrafo = celda.find(q("a:txBody")).find(q("a:p"))
                tramos = parrafo.findall(q("a:r"))
                for sobrante in tramos[1:]:
                    parrafo.remove(sobrante)
                tramos[0].find(q("a:t")).text = limpio(valor)
                # a:tc debe ir antes de a:extLst dentro de la fila.
                extension = fila.find(q("a:extLst"))
                if extension is not None:
                    extension.addprevious(celda)
                else:
                    fila.append(celda)
            tabla.append(fila)
        # La tabla del original llena el área de contenido; una más corta se
        # centra en ella en vez de quedarse pegada al título.
        arriba, abajo = 1596826, 5950000
        alto_tabla = alto * len(filas)
        libre = abajo - arriba - alto_tabla
        colocar(marco, y=arriba + (libre // 2 if libre > 400000 else 0), cy=alto_tabla)
        anadir(s, marco, "Tabla")
        return s

    def cronologia(self, d):
        s = self.con_cabecera(d)
        hitos = d["hitos"]
        anadir(s, self.frag.clonar("tiempo_linea"), "Línea de tiempo")
        diametro = 952752
        y_circulo, centro_y = 3047081, 3523457
        extremos = (
            (405607, d.get("icono_inicio", "pizarra")),
            (10762298, d.get("icono_fin", "copa")),
        )
        for (x, nombre), lado in zip(extremos, ("inicio", "fin")):
            anadir(s, colocar(self.frag.clonar("tiempo_circulo"), x, y_circulo, diametro, diametro), f"Círculo {lado}")
            icono = colorear(self.frag.clonar("icono_" + nombre), "bg1")
            ancho, alto = medidas(icono)
            anadir(s, colocar(icono, x + (diametro - ancho) / 2, centro_y - alto / 2), f"Icono {lado}")

        izquierda, derecha = 405607 + diametro, 10762298
        paso = (derecha - izquierda) / len(hitos)
        ancho_rotulo = paso - 100000
        ancho_texto = min(paso - 134000, 2600000)
        for i, hito in enumerate(hitos):
            centro = izquierda + (i + 0.5) * paso
            punto = self.frag.clonar("hito_punto")
            ancho, alto = medidas(punto)
            anadir(s, colocar(punto, centro - ancho / 2, centro_y - alto / 2), f"Punto hito {i + 1}")
            if hito.get("marca"):
                marca = escribir(self.frag.clonar("hito_marca"), [hito["marca"]])
                anadir(s, colocar(marca, centro - ancho_rotulo / 2, cx=ancho_rotulo), f"Marca hito {i + 1}")
            titulo = escribir(self.frag.clonar("hito_titulo"), [hito["titulo"]])
            anadir(s, colocar(titulo, centro - ancho_rotulo / 2, cx=ancho_rotulo), f"Título hito {i + 1}")
            if hito.get("texto"):
                texto = escribir(self.frag.clonar("hito_texto"), [hito["texto"]])
                anadir(s, colocar(texto, centro - ancho_texto / 2, cx=ancho_texto), f"Texto hito {i + 1}")
        return s

    def figura(self, d):
        s = self.con_cabecera(d)
        ruta = self.base / d["imagen"]
        vectorial = ruta.suffix.lower() == ".svg"
        tam_minimo = None
        if vectorial:
            texto_svg = ruta.read_text(encoding="utf-8")
            tam_minimo = conversor.texto_minimo(texto_svg)     # (font-size, ancho del viewBox)
            png = Path(self.tmp) / f"figura_{len(self.prs.slides)}.png"
            conversor.rasterizar(texto_svg, png)
            ruta = png
        izquierda, derecha, arriba, abajo = 911559, 11256630, 1650000, 5950000
        if d.get("puntos"):
            lista = escribir(self.frag.clonar("col_lista_a"), d["puntos"])
            espaciar_puntos(lista)
            anadir(s, colocar(lista, izquierda, 1800000, 3900000), "Puntos")
            izquierda += 3900000 + 250000
        if d.get("pie"):
            abajo -= 330000
        imagen = s.shapes.add_picture(str(ruta), 0, 0)
        escala = min((derecha - izquierda) / imagen.width, (abajo - arriba) / imagen.height)
        ancho, alto = int(imagen.width * escala), int(imagen.height * escala)
        imagen.left = int(izquierda + (derecha - izquierda - ancho) / 2)
        imagen.top = int(arriba + (abajo - arriba - alto) / 2)
        imagen.width, imagen.height = ancho, alto
        imagen.name = "Figura"
        if d.get("descripcion"):
            imagen._element.nvPicPr.cNvPr.set("descr", limpio(d["descripcion"]))
        if tam_minimo:
            puntos = tam_minimo[0] * (ancho / 12700) / tam_minimo[1]
            if puntos < 11:
                self.avisos.append(
                    f'{d["imagen"]}: su texto más pequeño quedará a {puntos:.0f} pt en la diapositiva; '
                    f"sube el font-size al menos a {tam_minimo[0] * 11 / puntos:.0f} o simplifica la figura")
        if not vectorial and imagen.image.size[0] < 1200:
            self.avisos.append(f'{d["imagen"]}: solo tiene {imagen.image.size[0]} px de ancho y se verá borrosa')
        if d.get("pie"):
            pie = escribir(self.frag.clonar("graf_texto"), [d["pie"]])
            anadir(s, colocar(pie, izquierda, imagen.top + alto + 60000, derecha - izquierda), "Pie de figura")
        return s

    def pie_fuentes(self, s, d):
        """Línea de fuentes al pie: cita APA breve de cada obra, «Autor (año)»."""
        partes = [f'{limpio(self.obras[c]["autores"])} ({limpio(self.obras[c]["anio"])})' for c in d.get("fuentes", [])]
        if d.get("nota_fuente"):
            nota = limpio(d["nota_fuente"]).rstrip(".")
            partes.append(nota if not partes else nota[0].lower() + nota[1:])
        if not partes:
            return
        texto = ("Fuente: " if len(partes) == 1 else "Fuentes: ") + "; ".join(partes) + "."
        xml = (
            f'<p:sp xmlns:p="{NS["p"]}" xmlns:a="{NS["a"]}">'
            '<p:nvSpPr><p:cNvPr id="0" name="Fuentes"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>'
            '<p:spPr><a:xfrm><a:off x="2400000" y="6330000"/><a:ext cx="8500000" cy="560000"/></a:xfrm>'
            '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/></p:spPr>'
            '<p:txBody><a:bodyPr wrap="square" rtlCol="0" anchor="ctr"><a:noAutofit/></a:bodyPr><a:lstStyle/>'
            '<a:p><a:r><a:rPr lang="es-ES" sz="1198"><a:solidFill><a:schemeClr val="tx2"/></a:solidFill>'
            '<a:latin typeface="Arial"/></a:rPr><a:t/></a:r></a:p></p:txBody></p:sp>'
        )
        forma = etree.fromstring(xml)
        forma.find(".//" + q("a:t")).text = texto
        anadir(s, forma)

    def referencias(self, d):
        """Lista final en formato APA: solo las obras citadas, por orden alfabético,
        con sangría francesa; se reparte en varias diapositivas si hace falta."""
        obras = sorted((self.obras[c]["referencia"] for c in self.citadas), key=orden_apa)
        izquierda, arriba, ancho, alto = 911559, 1678159, 10345071, 4250000
        linea, separacion, por_linea = 203200, 76200, 105
        paginas, actual, ocupado = [], [], 0
        for obra in obras:
            necesita = -(-len(obra.replace("*", "")) // por_linea) * linea + separacion
            if actual and ocupado + necesita > alto - 100000:
                paginas.append(actual)
                actual, ocupado = [], 0
            actual.append(obra)
            ocupado += necesita
        if actual:
            paginas.append(actual)
        creadas = []
        titulo = d.get("titulo") or "Referencias"
        for i, pagina in enumerate(paginas, 1):
            cabecera = {"antetitulo": d.get("antetitulo"),
                        "titulo": titulo if len(paginas) == 1 else f"{titulo} ({i}/{len(paginas)})"}
            s = self.con_cabecera(cabecera, "Texto")
            entradilla, cuerpo = marcador(s, 12), marcador(s, 13)
            entradilla._element.getparent().remove(entradilla._element)
            cuerpo.left, cuerpo.top, cuerpo.width, cuerpo.height = izquierda, arriba, ancho, alto
            cuerpo.name = "Lista de referencias"
            marco = cuerpo.text_frame
            for j, obra in enumerate(pagina):
                p = marco.paragraphs[0] if j == 0 else marco.add_paragraph()
                tramos_cursiva(p, obra)
                ppr = p._p.get_or_add_pPr()
                ppr.set("marL", "457200")        # sangría francesa de 1,27 cm
                ppr.set("indent", "-457200")
                espacio = etree.SubElement(ppr, q("a:spcAft"))
                sub(espacio, "a:spcPts", val=600)
            creadas.append(s)
        return creadas

    def cierre(self, d):
        s = self.nueva("Cierre")
        palabras = limpio(d.get("texto") or "Muchas gracias").split()
        parrafo = marcador(s, 0).text_frame.paragraphs[0]
        if len(palabras) > 1:
            parrafo.add_run().text = " ".join(palabras[:-1]) + " "
        ultima = parrafo.add_run()
        ultima.text = palabras[-1]
        if len(palabras) > 1:
            ultima.font.color.rgb = CORAL
        return s

    def pagina(self, diapositiva, n):
        numero_pagina(diapositiva, n)

    # Tipos que llevan número de página, como en la plantilla original.
    CON_PAGINA = ("texto", "columnas", "grafico", "tabla", "cronologia", "figura", "referencias")

    def generar(self, spec, salida):
        diapositivas = list(spec["diapositivas"])
        self.obras = spec.get("referencias") or {}
        for d in diapositivas:
            for clave in d.get("fuentes", []):
                if clave not in self.citadas:
                    self.citadas.append(clave)
        # Si hay citas y nadie ha colocado la lista de referencias, va al final,
        # justo antes del cierre.
        if self.citadas and not any(d["tipo"] == "referencias" for d in diapositivas):
            posicion = len(diapositivas) - 1 if diapositivas[-1]["tipo"] == "cierre" else len(diapositivas)
            diapositivas.insert(posicion, {"tipo": "referencias"})
        with tempfile.TemporaryDirectory() as tmp:
            self.tmp = tmp
            for d in diapositivas:
                if d["tipo"] == "referencias":
                    creadas = self.referencias(d)
                else:
                    creadas = [getattr(self, d["tipo"])(d)]
                for diapositiva in creadas:
                    if d["tipo"] in self.CON_PAGINA:
                        self.pagina(diapositiva, self.prs.slides.index(diapositiva) + 1)
                    if d["tipo"] in CON_FUENTES or d["tipo"] in ("agenda", "referencias"):
                        self.pie_fuentes(diapositiva, d)
                    if d.get("notas"):
                        diapositiva.notes_slide.notes_text_frame.text = limpio(d["notas"])
        if spec.get("titulo"):
            self.prs.core_properties.title = limpio(spec["titulo"])
        if spec.get("autor"):
            self.prs.core_properties.author = limpio(spec["autor"])
        self.prs.save(str(salida))


class GeneradorUnir(Generador):
    """Generador de UNIR. Su plantilla tiene marcadores de posición en todos los
    diseños, así que casi todo se rellena en ellos; columnas, cifras, hitos y
    tabla se componen con las formas modelo de sus diapositivas de ejemplo.
    Medidas en EMU sobre un lienzo de 24 384 000 x 13 716 000."""

    X0, ANCHO = 3227388, 19550062          # área de contenido
    Y0, Y1 = 3641465, 12500000
    GRIS, GRIS_CLARO = RGBColor(0x95, 0x9C, 0xAF), RGBColor(0xD3, 0xD6, 0xDE)
    MARINO = RGBColor(0x05, 0x27, 0x61)
    CON_PAGINA = ("separador", "agenda", "texto", "cita", "columnas", "grafico", "cifras",
                  "tabla", "cronologia", "figura", "referencias")
    PIE = {"Texto": 2, "Agenda": None, "Cita": 1, "Cifras": 1}

    # ---- utilidades --------------------------------------------------------
    def pagina(self, diapositiva, n):
        xml = (
            f'<p:sp xmlns:p="{NS["p"]}" xmlns:a="{NS["a"]}">'
            '<p:nvSpPr><p:cNvPr id="0" name="Número de página"/>'
            '<p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr>'
            '<p:nvPr><p:ph type="sldNum" idx="12"/></p:nvPr></p:nvSpPr>'
            "<p:spPr/><p:txBody><a:bodyPr/><a:lstStyle/><a:p>"
            '<a:fld id="{00000000-1234-1234-1234-123412341234}" type="slidenum">'
            f'<a:rPr lang="es-ES"/><a:t>{n}</a:t></a:fld></a:p></p:txBody></p:sp>'
        )
        anadir(diapositiva, etree.fromstring(xml))

    def pie_fuentes(self, s, d):
        idx = self.PIE.get(s.slide_layout.name)
        partes = [f'{limpio(self.obras[c]["autores"])} ({limpio(self.obras[c]["anio"])})' for c in d.get("fuentes", [])]
        if d.get("nota_fuente"):
            nota = limpio(d["nota_fuente"]).rstrip(".")
            partes.append(nota if not partes else nota[0].lower() + nota[1:])
        if idx is None:
            return
        pie = marcador(s, idx)
        if not partes:
            pie._element.getparent().remove(pie._element)
            return
        pie.text_frame.text = ("Fuente: " if len(partes) == 1 else "Fuentes: ") + "; ".join(partes) + "."
        pie.name = "Fuentes"

    def con_cabecera(self, d, diseno="Texto"):
        """Diapositiva con título en mayúsculas, como en la plantilla, y el
        antetítulo en la línea pequeña de debajo."""
        s = self.nueva(diseno)
        rellenar(s, 0, limpio(d["titulo"]).upper())
        rellenar(s, 3, limpio(d["antetitulo"]).upper() if d.get("antetitulo") else None)
        return s

    def sin_cuerpo(self, s):
        cuerpo = marcador(s, 1)
        cuerpo._element.getparent().remove(cuerpo._element)

    def _vineta(self, parrafo, primero):
        ppr = parrafo._p.get_or_add_pPr()
        ppr.set("marL", "457200")
        ppr.set("indent", "-457200")
        if not primero:
            sub(etree.SubElement(ppr, q("a:spcBef")), "a:spcPts", val=2000)
        color = etree.SubElement(ppr, q("a:buClr"))
        sub(color, "a:srgbClr", val="959CAF")
        sub(ppr, "a:buChar", char="•")

    def _separado(self, parrafo, primero=False):
        """Párrafo corrido: sin la viñeta que el diseño pone por defecto."""
        ppr = parrafo._p.get_or_add_pPr()
        ppr.set("marL", "0")
        ppr.set("indent", "0")
        if not primero:
            sub(etree.SubElement(ppr, q("a:spcBef")), "a:spcPts", val=2000)
        sub(ppr, "a:buNone")

    # ---- tipos -------------------------------------------------------------
    def portada(self, d):
        s = self.nueva("Portada")
        titulo = rellenar(s, 0, d["titulo"])
        if len(limpio(d["titulo"])) > 44:        # el título de muestra cabe en dos líneas de 150 pt
            for parrafo in titulo.text_frame.paragraphs:
                for tramo in parrafo.runs:
                    tramo.font.size = Pt(110)
        linea = " · ".join(limpio(d[c]) for c in ("autor", "pie") if d.get(c))
        autor = rellenar(s, 1, linea or None)
        if autor is not None:
            autor.text_frame.paragraphs[0].runs[0].font.size = Pt(30)
        if d.get("subtitulo"):
            anadir(s, escribir(self.frag.clonar("portada_subtitulo"), [d["subtitulo"]]), "Subtítulo")
        return s

    def separador(self, d):
        color = d.get("color") or self.marca["separadores"][0]
        s = self.nueva("Separador " + color)
        rellenar(s, 0, limpio(d["titulo"]).upper())
        rellenar(s, 1, str(d["numero"]).zfill(2) if d.get("numero") is not None else None)
        pie = rellenar(s, 2, limpio(d["subtitulo"]).upper() if d.get("subtitulo") else None)
        if pie is not None:
            pie.name = "Subtítulo"
        return s

    def agenda(self, d):
        s = self.nueva("Agenda")
        rellenar(s, 0, limpio(d.get("titulo") or "Agenda").upper())
        rellenar(s, 2, limpio(d["antetitulo"]).upper() if d.get("antetitulo") else None)
        marco = marcador(s, 1).text_frame
        for i, punto in enumerate(d["puntos"]):
            p = marco.paragraphs[0] if i == 0 else marco.add_paragraph()
            p.add_run().text = limpio(punto)
            ppr = p._p.get_or_add_pPr()
            ppr.set("marL", "1071563")
            ppr.set("indent", "-1071563")
            if i:
                sub(etree.SubElement(ppr, q("a:spcBef")), "a:spcPts", val=2000)
            color = etree.SubElement(ppr, q("a:buClr"))
            sub(color, "a:srgbClr", val="959CAF")
            sub(ppr, "a:buFont", typeface="Arial")
            sub(ppr, "a:buAutoNum", type="arabicPeriod")
        return s

    def texto(self, d):
        s = self.con_cabecera(d)
        marco = marcador(s, 1).text_frame
        primero = True

        def parrafo():
            nonlocal primero
            p = marco.paragraphs[0] if primero else marco.add_paragraph()
            self._separado(p, primero)
            primero = False
            return p

        if d.get("entradilla"):
            p = parrafo()
            tramo = p.add_run()
            tramo.text = limpio(d["entradilla"])
            tramo.font.bold = True
            if d.get("nota"):
                nota = p.add_run()
                nota.text = " – " + limpio(d["nota"])
                nota.font.color.rgb = self.GRIS
        for t in d.get("cuerpo", []):
            parrafo().add_run().text = limpio(t)
        for t in d.get("lista", []):
            era_primero = primero
            p = marco.paragraphs[0] if primero else marco.add_paragraph()
            primero = False
            p.add_run().text = limpio(t)
            self._vineta(p, era_primero)
        return s

    def cita(self, d):
        s = self.nueva("Cita")
        texto = limpio(d["texto"])
        titulo = marcador(s, 0)
        p = titulo.text_frame.paragraphs[0]
        tramo = p.add_run()
        tramo.text = texto
        tramo.font.size = Pt(100 if len(texto) <= 120 else 80)
        if d.get("autor"):
            p.add_line_break()
            autor = p.add_run()
            autor.text = "— " + limpio(d["autor"])
            autor.font.size = Pt(34)
            autor.font.bold = False
            autor.font.color.rgb = RGBColor(0, 0, 0)
        return s

    def _reparto(self, n):
        paso = self.ANCHO / n
        return [self.X0 + i * paso for i in range(n)], paso

    def columnas(self, d):
        s = self.con_cabecera(d)
        self.sin_cuerpo(s)
        xs, paso = self._reparto(len(d["columnas"]))
        ancho_caja = 3276600
        for i, (x, col) in enumerate(zip(xs, d["columnas"])):
            anadir(s, colocar(self.frag.clonar("col_caja"), x), f"Caja columna {i + 1}")
            marca = escribir(self.frag.clonar("col_marca"), [str(col.get("marca") or i + 1)[:2]])
            marca.find(".//" + q("a:pPr")).set("algn", "ctr")
            anadir(s, colocar(marca, x, cx=ancho_caja), f"Marca columna {i + 1}")
            textos = escribir(self.frag.clonar("col_texto"), [limpio(col["rotulo"]).upper()] + list(col["puntos"]))
            anadir(s, colocar(textos, x, cx=paso - 850000), f"Lista columna {i + 1}")
        return s

    def cifras(self, d):
        s = self.nueva("Cifras")
        blanco = RGBColor(0xFF, 0xFF, 0xFF)
        for idx, clave in ((0, "titulo"), (3, "antetitulo")):
            forma = rellenar(s, idx, limpio(d[clave]).upper() if d.get(clave) else None)
            if forma is not None:                 # sobre la franja azul, el texto va en blanco
                forma.text_frame.paragraphs[0].runs[0].font.color.rgb = blanco
        xs, paso = self._reparto(len(d["cifras"]))
        for i, (x, cifra) in enumerate(zip(xs, d["cifras"])):
            if cifra.get("detalle"):
                etiqueta = escribir(self.frag.clonar("cifra_etiqueta"), [limpio(cifra["detalle"]).upper()])
                anadir(s, colocar(etiqueta, x + 16329, cx=paso - 300000), f"Etiqueta cifra {i + 1}")
            valor = escribir(self.frag.clonar("cifra_valor"), [cifra["valor"]])
            anadir(s, colocar(valor, x + 53168, cx=paso - 300000), f"Cifra {i + 1}")
            texto = escribir(self.frag.clonar("cifra_texto"), [limpio(cifra["texto"]).upper()])
            anadir(s, colocar(texto, x, cx=paso - 400000), f"Texto cifra {i + 1}")
        return s

    def cronologia(self, d):
        s = self.con_cabecera(d)
        self.sin_cuerpo(s)
        hitos = d["hitos"]
        xs, paso = self._reparto(len(hitos))
        dentro = len(hitos) <= 4                  # con pocos hitos, la marca cabe en la caja
        ancho_caja = paso - 930000 if dentro else 1357746
        for i, (x, hito) in enumerate(zip(xs, hitos)):
            anadir(s, colocar(self.frag.clonar("hito_caja"), x, cx=ancho_caja), f"Caja hito {i + 1}")
            numero = escribir(self.frag.clonar("hito_numero"), [str(i + 1)])
            if dentro:
                anadir(s, colocar(numero, x + 569840), f"Número hito {i + 1}")
                if hito.get("marca"):
                    anadir(s, colocar(self.frag.clonar("hito_linea"), x + 1655762), f"Línea hito {i + 1}")
                    marca = escribir(self.frag.clonar("hito_marca"), [hito["marca"]])
                    anadir(s, colocar(marca, x + 2242080, cx=ancho_caja - 2400000), f"Marca hito {i + 1}")
            else:
                numero.find(".//" + q("a:pPr")).set("algn", "ctr")
                anadir(s, colocar(numero, x, cx=ancho_caja), f"Número hito {i + 1}")
            lineas = [limpio(hito["titulo"]).upper()]
            if not dentro and hito.get("marca"):
                lineas[0] = limpio(hito["marca"]).upper() + " · " + lineas[0]
            if hito.get("texto"):
                lineas.append(hito["texto"])
            texto = escribir(self.frag.clonar("hito_texto"), lineas)
            anadir(s, colocar(texto, x, cx=paso - 400000), f"Texto hito {i + 1}")
        return s

    def tabla(self, d):
        s = self.con_cabecera(d)
        self.sin_cuerpo(s)
        marco = self.frag.clonar("tabla")
        tabla = marco.find(".//" + q("a:tbl"))
        modelos = tabla.findall(q("a:tr"))
        m_cabecera, m_fila, m_total = modelos[0], modelos[1], modelos[-1]
        for fila in modelos:
            tabla.remove(fila)
        cabecera = d["cabecera"]
        filas = [(m_cabecera, cabecera)] + [(m_fila, f) for f in d["filas"]]
        if d.get("total"):
            filas.append((m_total, d["total"]))
        rejilla = tabla.find(q("a:tblGrid"))
        for c in list(rejilla):
            rejilla.remove(c)
        ancho = self.ANCHO // len(cabecera)
        for _ in cabecera:
            sub(rejilla, "a:gridCol", w=ancho)
        alto = 850000                             # una línea de 28 pt con sus márgenes
        for modelo, celdas in filas:
            fila = copy.deepcopy(modelo)
            fila.set("h", str(alto))
            originales = fila.findall(q("a:tc"))
            # La primera celda de la cabecera del ejemplo está vacía y sin formato:
            # la segunda sirve de modelo para todas.
            patron = originales[1] if modelo is m_cabecera else originales[0]
            for c in originales:
                fila.remove(c)
            for valor in celdas:
                celda = copy.deepcopy(patron)
                parrafo = celda.find(q("a:txBody")).find(q("a:p"))
                tramos = parrafo.findall(q("a:r"))
                for sobrante in tramos[1:] + parrafo.findall(q("a:br")):
                    parrafo.remove(sobrante)
                tramos[0].find(q("a:t")).text = limpio(valor)
                extension = fila.find(q("a:extLst"))
                if extension is not None:
                    extension.addprevious(celda)
                else:
                    fila.append(celda)
            tabla.append(fila)
        alto_tabla = alto * len(filas)
        y = self.Y0 + max(0, (self.Y1 - self.Y0 - alto_tabla) // 2)
        colocar(marco, self.X0, y, ancho * len(cabecera), alto_tabla)
        anadir(s, marco, "Tabla")
        return s

    def _estilo_ejes(self, grafico, d, formato):
        valores = grafico.value_axis
        valores.has_major_gridlines = True
        valores.major_gridlines.format.line.color.rgb = self.GRIS_CLARO
        valores.major_gridlines.format.line.width = Emu(12700)
        valores.format.line.fill.background()
        for eje, tam in ((valores, 28), (grafico.category_axis, 32)):
            eje.tick_labels.font.size = Pt(tam)
            eje.tick_labels.font.color.rgb = self.GRIS
            if formato and (eje is valores or d.get("grafico") == "dispersion"):
                eje.tick_labels.number_format = formato
                eje.tick_labels.number_format_is_linked = False
        grafico.category_axis.format.line.color.rgb = self.GRIS_CLARO
        grafico.category_axis.has_major_gridlines = False
        for eje, clave in ((grafico.category_axis, "eje_x"), (valores, "eje_y")):
            if d.get(clave):
                eje.has_title = True
                marco = eje.axis_title.text_frame
                marco.text = limpio(d[clave])
                fuente = marco.paragraphs[0].runs[0].font
                fuente.size, fuente.bold = Pt(28), False
                fuente.color.rgb = RGBColor(0x53, 0x53, 0x53)
        if d.get("eje_minimo") is not None:
            valores.minimum_scale = d["eje_minimo"]
        if d.get("eje_maximo") is not None:
            valores.maximum_scale = d["eje_maximo"]

    def _leyenda(self, grafico, visible):
        grafico.has_legend = visible
        if visible:
            grafico.legend.position = XL_LEGEND_POSITION.BOTTOM
            grafico.legend.include_in_layout = False
            grafico.legend.font.size = Pt(28)
            grafico.legend.font.color.rgb = RGBColor(0x53, 0x53, 0x53)

    def grafico(self, d):
        s = self.con_cabecera(d)
        self.sin_cuerpo(s)
        dispersion = d.get("grafico") == "dispersion"
        lineas = d.get("grafico") == "lineas"
        series = d["series"]
        if dispersion:
            datos = XyChartData()
            for serie in series:
                puntos = datos.add_series(limpio(serie.get("nombre", "")))
                for x, y in serie["puntos"]:
                    puntos.add_data_point(x, y)
            tipo = XL_CHART_TYPE.XY_SCATTER
        else:
            datos = CategoryChartData()
            datos.categories = [limpio(c) for c in d["categorias"]]
            for serie in series:
                datos.add_series(limpio(serie.get("nombre", "")), serie["valores"])
            tipo = XL_CHART_TYPE.LINE_MARKERS if lineas else XL_CHART_TYPE.COLUMN_CLUSTERED
        marco = s.shapes.add_chart(tipo, Emu(self.X0), Emu(self.Y0), Emu(self.ANCHO), Emu(self.Y1 - self.Y0), datos)
        grafico = marco.chart
        grafico.has_title = False
        self._idioma(grafico)
        formato = self._formato(d)
        trazado = grafico.plots[0]
        if not dispersion:
            if not lineas:
                trazado.gap_width = 80
                trazado.overlap = -10
            trazado.has_data_labels = True
            etiquetas = trazado.data_labels
            etiquetas.position = XL_LABEL_POSITION.ABOVE if lineas else XL_LABEL_POSITION.OUTSIDE_END
            etiquetas.font.size = Pt(40)
            etiquetas.font.bold = True
            etiquetas.font.color.rgb = self.MARINO
            if formato:
                etiquetas.number_format = formato
                etiquetas.number_format_is_linked = False
        for i, (serie, definicion) in enumerate(zip(trazado.series, series)):
            color = RGBColor.from_string(self.colores_serie[i % len(self.colores_serie)])
            if dispersion and not definicion.get("linea"):
                serie.format.line.fill.background()
                serie.marker.style = XL_MARKER_STYLE.CIRCLE
                serie.marker.size = 14
                serie.marker.format.fill.solid()
                serie.marker.format.fill.fore_color.rgb = color
                serie.marker.format.line.fill.background()
            elif dispersion or lineas:
                serie.format.line.color.rgb = color
                serie.format.line.width = Pt(4.5)
                serie.smooth = False
                if dispersion:
                    serie.marker.style = XL_MARKER_STYLE.NONE
                else:
                    serie.marker.format.fill.solid()
                    serie.marker.format.fill.fore_color.rgb = color
                    serie.marker.format.line.color.rgb = color
            else:
                serie.format.fill.solid()
                serie.format.fill.fore_color.rgb = color
        self._estilo_ejes(grafico, d, formato)
        if not dispersion and not lineas and d.get("eje_minimo") is None \
                and all(v >= 0 for serie in series for v in serie["valores"]):
            grafico.value_axis.minimum_scale = 0
        self._leyenda(grafico, len(series) > 1)
        return s

    def figura(self, d):
        s = self.con_cabecera(d)
        ruta = self.base / d["imagen"]
        vectorial = ruta.suffix.lower() == ".svg"
        tam_minimo = None
        if vectorial:
            texto_svg = ruta.read_text(encoding="utf-8")
            tam_minimo = conversor.texto_minimo(texto_svg)
            png = Path(self.tmp) / f"figura_{len(self.prs.slides)}.png"
            conversor.rasterizar(texto_svg, png)
            ruta = png
        izquierda, derecha, arriba, abajo = self.X0, self.X0 + self.ANCHO, self.Y0, self.Y1
        cuerpo = marcador(s, 1)
        if d.get("puntos"):
            ancho_texto = 7400000
            cuerpo.left, cuerpo.top, cuerpo.width, cuerpo.height = izquierda, arriba, ancho_texto, abajo - arriba
            for i, punto in enumerate(d["puntos"]):
                p = cuerpo.text_frame.paragraphs[0] if i == 0 else cuerpo.text_frame.add_paragraph()
                p.add_run().text = limpio(punto)
                self._vineta(p, i == 0)
            izquierda += ancho_texto + 500000
        else:
            cuerpo._element.getparent().remove(cuerpo._element)
        if d.get("pie"):
            abajo -= 650000
        imagen = s.shapes.add_picture(str(ruta), 0, 0)
        escala = min((derecha - izquierda) / imagen.width, (abajo - arriba) / imagen.height)
        ancho, alto = int(imagen.width * escala), int(imagen.height * escala)
        imagen.left = int(izquierda + (derecha - izquierda - ancho) / 2)
        imagen.top = int(arriba + (abajo - arriba - alto) / 2)
        imagen.width, imagen.height = ancho, alto
        imagen.name = "Figura"
        if d.get("descripcion"):
            imagen._element.nvPicPr.cNvPr.set("descr", limpio(d["descripcion"]))
        if tam_minimo:
            # El lienzo de UNIR es el doble de grande: 22 pt aquí equivalen a 11 pt.
            puntos = tam_minimo[0] * (ancho / 12700) / tam_minimo[1]
            if puntos < 22:
                self.avisos.append(
                    f'{d["imagen"]}: su texto más pequeño quedará demasiado pequeño en la diapositiva; '
                    f"sube el font-size al menos a {tam_minimo[0] * 22 / puntos:.0f} o simplifica la figura")
        if not vectorial and imagen.image.size[0] < 1200:
            self.avisos.append(f'{d["imagen"]}: solo tiene {imagen.image.size[0]} px de ancho y se verá borrosa')
        if d.get("pie"):
            pie = escribir(self.frag.clonar("cifra_etiqueta"), [d["pie"]])
            tramo = pie.find(".//" + q("a:rPr"))
            tramo.set("sz", "2400")
            relleno = tramo.find(q("a:solidFill"))
            for hijo in list(relleno):
                relleno.remove(hijo)
            sub(relleno, "a:srgbClr", val="535353")
            pie.find(".//" + q("a:pPr")).set("algn", "ctr")
            anadir(s, colocar(pie, izquierda, imagen.top + alto + 120000, derecha - izquierda), "Pie de figura")
        return s

    def referencias(self, d):
        obras = sorted((self.obras[c]["referencia"] for c in self.citadas), key=orden_apa)
        alto = self.Y1 - self.Y0
        linea, separacion, por_linea = 533400, 254000, 100      # 28 pt a 1,5 líneas
        paginas, actual, ocupado = [], [], 0
        for obra in obras:
            necesita = -(-len(obra.replace("*", "")) // por_linea) * linea + separacion
            if actual and ocupado + necesita > alto:
                paginas.append(actual)
                actual, ocupado = [], 0
            actual.append(obra)
            ocupado += necesita
        if actual:
            paginas.append(actual)
        creadas = []
        titulo = d.get("titulo") or "Referencias"
        for i, pagina in enumerate(paginas, 1):
            s = self.con_cabecera({"antetitulo": d.get("antetitulo"),
                                   "titulo": titulo if len(paginas) == 1 else f"{titulo} ({i}/{len(paginas)})"})
            cuerpo = marcador(s, 1)
            cuerpo.left, cuerpo.top, cuerpo.width, cuerpo.height = self.X0, self.Y0, self.ANCHO, alto
            cuerpo.name = "Lista de referencias"
            for j, obra in enumerate(pagina):
                p = cuerpo.text_frame.paragraphs[0] if j == 0 else cuerpo.text_frame.add_paragraph()
                tramos_cursiva(p, obra)
                for tramo in p.runs:
                    tramo.font.size = Pt(28)
                ppr = p._p.get_or_add_pPr()
                ppr.set("marL", "914400")            # sangría francesa
                ppr.set("indent", "-914400")
                if j:
                    sub(etree.SubElement(ppr, q("a:spcBef")), "a:spcPts", val=2000)
                sub(ppr, "a:buNone")
            creadas.append(s)
        return creadas

    def cierre(self, d):
        s = self.nueva("Cierre")
        rellenar(s, 0, d.get("texto") or "Gracias")
        return s

    def generar(self, spec, salida):
        super().generar(spec, salida)


GENERADORES = {"unipro": Generador, "unir": GeneradorUnir}


def main(argv):
    if len(argv) != 3:
        print(__doc__, file=sys.stderr)
        return 2
    entrada, salida = Path(argv[1]), Path(argv[2])
    try:
        spec = json.loads(entrada.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        print(f"[!] No se puede leer {entrada}: {e}", file=sys.stderr)
        return 1
    v = validar(spec, entrada.parent)
    for aviso in v.avisos:
        print(f"[*] Aviso - {aviso}", file=sys.stderr)
    if v.errores:
        for error in v.errores:
            print(f"[!] Error - {error}", file=sys.stderr)
        print(f"[!] No se ha generado nada: {len(v.errores)} error(es) en la especificación.", file=sys.stderr)
        return 1
    if salida.suffix.lower() != ".pptx":
        salida = salida.with_suffix(".pptx")
    salida.parent.mkdir(parents=True, exist_ok=True)
    marca = cargar_marca(spec["institucion"].strip().lower())
    generador = GENERADORES[marca["clave"]](marca, entrada.parent)
    try:
        generador.generar(spec, salida)
    except RuntimeError as e:
        print(f"[!] {e}", file=sys.stderr)
        return 3
    for aviso in generador.avisos:
        print(f"[*] Aviso - {aviso}", file=sys.stderr)
    avisos = len(v.avisos) + len(generador.avisos)
    print(f"[OK] {salida} ({len(generador.prs.slides)} diapositivas, {avisos} aviso(s))")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
