#!/usr/bin/env python3
# Creado por 686f6c61.dev (https://686f6c61.dev)
# /// script
# requires-python = ">=3.10"
# dependencies = ["pillow>=10", "pymupdf>=1.24"]
# ///
"""Renderiza una presentación a una hoja de contactos PNG para revisarla.

Uso:
    uv run revisar.py PRESENTACION.pptx [HOJA.png]

Necesita LibreOffice (soffice) para convertir el .pptx a PDF. Si no está
disponible lo indica y sale con código 3: en ese caso la revisión visual no se
puede hacer y hay que decírselo al usuario.
"""

import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


PERFIL_ES = (
    '<?xml version="1.0" encoding="UTF-8"?>'
    '<oor:items xmlns:oor="http://openoffice.org/2001/registry">'
    '<item oor:path="/org.openoffice.Setup/L10N">'
    '<prop oor:name="ooSetupSystemLocale" oor:op="fuse"><value>es-ES</value></prop></item>'
    "</oor:items>"
)


def perfil_espanol(carpeta):
    """Crea un perfil de LibreOffice con configuración regional española, para
    que los decimales de los gráficos salgan con coma en cualquier equipo."""
    usuario = Path(carpeta) / "perfil" / "user"
    usuario.mkdir(parents=True, exist_ok=True)
    (usuario / "registrymodifications.xcu").write_text(PERFIL_ES, encoding="utf-8")
    return f"-env:UserInstallation=file://{carpeta}/perfil"


def paginas_png(pdf, carpeta, ancho=640):
    """Convierte cada página del PDF en un PNG; devuelve las rutas en orden."""
    try:
        import pymupdf as fitz
    except ImportError:
        fitz = None
    if fitz is not None:
        rutas = []
        with fitz.open(str(pdf)) as documento:
            for i, pagina in enumerate(documento, 1):
                escala = ancho / pagina.rect.width
                ruta = carpeta / f"p-{i:03d}.png"
                pagina.get_pixmap(matrix=fitz.Matrix(escala, escala)).save(str(ruta))
                rutas.append(ruta)
        return rutas
    if shutil.which("pdftoppm"):
        subprocess.run(
            ["pdftoppm", "-png", "-scale-to-x", str(ancho), "-scale-to-y", "-1", str(pdf), str(carpeta / "p")],
            check=True,
        )
        return sorted(carpeta.glob("p-*.png"))
    return None


def main(argv):
    if len(argv) not in (2, 3):
        print(__doc__, file=sys.stderr)
        return 2
    pptx = Path(argv[1]).resolve()
    hoja = Path(argv[2]).resolve() if len(argv) == 3 else pptx.with_name(pptx.stem + "_revision.png")
    if not pptx.is_file():
        print(f"[!] No existe {pptx}", file=sys.stderr)
        return 1
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if not soffice:
        print("[!] LibreOffice no está instalado: no se puede renderizar la presentación.", file=sys.stderr)
        return 3
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        print("[!] Falta Pillow (ejecuta el script con «uv run» o instala pillow).", file=sys.stderr)
        return 3

    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        resultado = subprocess.run(
            [soffice, "--headless", perfil_espanol(tmp),
             "--convert-to", "pdf", "--outdir", str(tmp), str(pptx)],
            capture_output=True, text=True, timeout=300,
        )
        pdf = tmp / (pptx.stem + ".pdf")
        if not pdf.is_file():
            print(f"[!] LibreOffice no ha generado el PDF.\n{resultado.stderr.strip()}", file=sys.stderr)
            return 1
        rutas = paginas_png(pdf, tmp)
        if not rutas:
            print("[!] No hay forma de convertir el PDF a imágenes (falta PyMuPDF o pdftoppm).", file=sys.stderr)
            return 3

        imagenes = [Image.open(r).convert("RGB") for r in rutas]
        ancho, alto = imagenes[0].size
        columnas = 3 if len(imagenes) > 4 else 2
        filas = -(-len(imagenes) // columnas)
        margen, pie = 12, 22
        lienzo = Image.new(
            "RGB",
            (columnas * (ancho + margen) + margen, filas * (alto + pie + margen) + margen),
            "#7F7F7F",
        )
        dibujo = ImageDraw.Draw(lienzo)
        for i, imagen in enumerate(imagenes):
            x = margen + (i % columnas) * (ancho + margen)
            y = margen + (i // columnas) * (alto + pie + margen)
            lienzo.paste(imagen, (x, y))
            dibujo.text((x + 4, y + alto + 4), f"Diapositiva {i + 1}", fill="white")
        hoja.parent.mkdir(parents=True, exist_ok=True)
        lienzo.save(str(hoja))
    print(f"[OK] {hoja} ({len(imagenes)} diapositivas)")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
